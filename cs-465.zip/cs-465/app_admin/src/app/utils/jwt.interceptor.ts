import { Injectable, Provider } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HTTP_INTERCEPTORS } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AuthenticationService } from '../services/authentication.service';

@Injectable()
export class JwtInterceptor implements HttpInterceptor {
  constructor(private authenticationService: AuthenticationService) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const isAuthAPI = request.url.includes('login') || request.url.includes('register');

    // Pre-validate token before making request
    if (!isAuthAPI && this.authenticationService.getToken()) {
      if (!this.authenticationService.isLoggedIn()) {
        // Token is expired or invalid, don't send request
        console.log('Token expired, redirecting to login');
        this.authenticationService.logout();
        return throwError(() => new Error('Token expired'));
      }

      const token = this.authenticationService.getToken();
      const authReq = request.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      return next.handle(authReq).pipe(
        catchError(error => {
          // Handle 401 responses by logging out
          if (error.status === 401) {
            console.log('Received 401, logging out');
            this.authenticationService.logout();
          }
          return throwError(() => error);
        })
      );
    }

    return next.handle(request);
  }
}

export const authInterceptProvider: Provider = {
  provide: HTTP_INTERCEPTORS,
  useClass: JwtInterceptor,
  multi: true
};
