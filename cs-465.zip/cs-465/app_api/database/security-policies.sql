-- Row-Level Security Policies and Audit Triggers
-- Implements comprehensive security controls for data access

-- Enable row-level security on sensitive tables
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_sessions ENABLE ROW LEVEL SECURITY;

-- Create security roles
CREATE ROLE travlr_app;
CREATE ROLE travlr_admin;
CREATE ROLE travlr_readonly;

-- Grant basic permissions
GRANT USAGE ON SCHEMA public TO travlr_app, travlr_admin, travlr_readonly;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO travlr_app;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO travlr_admin;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO travlr_readonly;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO travlr_app, travlr_admin;

-- Row-Level Security Policies for Bookings
-- Users can only see their own bookings
CREATE POLICY user_bookings_select_policy ON bookings
    FOR SELECT
    USING (
        user_id = current_setting('app.user_id')::INTEGER 
        OR current_setting('app.user_role') IN ('admin', 'manager')
    );

-- Users can only insert their own bookings
CREATE POLICY user_bookings_insert_policy ON bookings
    FOR INSERT
    WITH CHECK (
        user_id = current_setting('app.user_id')::INTEGER
        AND booking_status = 'pending'
    );

-- Users can only update their own pending bookings
CREATE POLICY user_bookings_update_policy ON bookings
    FOR UPDATE
    USING (
        user_id = current_setting('app.user_id')::INTEGER 
        AND booking_status = 'pending'
        OR current_setting('app.user_role') IN ('admin', 'manager')
    );

-- Only admins can delete bookings
CREATE POLICY admin_bookings_delete_policy ON bookings
    FOR DELETE
    USING (current_setting('app.user_role') = 'admin');

-- Row-Level Security Policies for Payments
-- Users can only see payments for their own bookings
CREATE POLICY user_payments_select_policy ON payments
    FOR SELECT
    USING (
        booking_id IN (
            SELECT booking_id FROM bookings 
            WHERE user_id = current_setting('app.user_id')::INTEGER
        )
        OR current_setting('app.user_role') IN ('admin', 'manager')
    );

-- Only system can create payment records
CREATE POLICY system_payments_insert_policy ON payments
    FOR INSERT
    WITH CHECK (current_setting('app.user_role') = 'system');

-- Only system and admins can update payments
CREATE POLICY system_payments_update_policy ON payments
    FOR UPDATE
    USING (current_setting('app.user_role') IN ('system', 'admin'));

-- Row-Level Security Policies for Users
-- Users can only see their own profile
CREATE POLICY user_profile_select_policy ON users
    FOR SELECT
    USING (
        user_id = current_setting('app.user_id')::INTEGER 
        OR current_setting('app.user_role') IN ('admin', 'manager')
    );

-- Users can only update their own profile
CREATE POLICY user_profile_update_policy ON users
    FOR UPDATE
    USING (
        user_id = current_setting('app.user_id')::INTEGER
        OR current_setting('app.user_role') IN ('admin', 'manager')
    );

-- Only system can create users (registration)
CREATE POLICY system_users_insert_policy ON users
    FOR INSERT
    WITH CHECK (current_setting('app.user_role') = 'system');

-- Row-Level Security Policies for User Sessions
-- Users can only see their own sessions
CREATE POLICY user_sessions_select_policy ON user_sessions
    FOR SELECT
    USING (
        user_id = current_setting('app.user_id')::INTEGER 
        OR current_setting('app.user_role') IN ('admin', 'manager')
    );

-- System can manage all sessions
CREATE POLICY system_sessions_policy ON user_sessions
    FOR ALL
    USING (current_setting('app.user_role') = 'system');

-- Audit trigger function
CREATE OR REPLACE FUNCTION log_data_change()
RETURNS TRIGGER AS $$
DECLARE
    old_json JSONB;
    new_json JSONB;
    user_id_val INTEGER;
    session_id_val VARCHAR(255);
BEGIN
    -- Get current user and session from application context
    BEGIN
        user_id_val := current_setting('app.user_id')::INTEGER;
    EXCEPTION WHEN OTHERS THEN
        user_id_val := NULL;
    END;
    
    BEGIN
        session_id_val := current_setting('app.session_id');
    EXCEPTION WHEN OTHERS THEN
        session_id_val := NULL;
    END;

    -- Convert records to JSON
    IF TG_OP = 'INSERT' THEN
        new_json := row_to_json(NEW);
        old_json := NULL;
    ELSIF TG_OP = 'UPDATE' THEN
        old_json := row_to_json(OLD);
        new_json := row_to_json(NEW);
    ELSIF TG_OP = 'DELETE' THEN
        old_json := row_to_json(OLD);
        new_json := NULL;
    END IF;

    -- Insert audit record
    INSERT INTO audit_log (
        table_name, 
        operation, 
        user_id, 
        record_id, 
        old_values, 
        new_values,
        ip_address,
        session_id
    ) VALUES (
        TG_TABLE_NAME, 
        TG_OP,
        user_id_val,
        COALESCE(NEW.id, OLD.id),
        old_json, 
        new_json,
        inet_client_addr(),
        session_id_val
    );

    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Attach audit triggers to all tables
CREATE TRIGGER users_audit_trigger
    AFTER INSERT OR UPDATE OR DELETE ON users
    FOR EACH ROW EXECUTE FUNCTION log_data_change();

CREATE TRIGGER bookings_audit_trigger
    AFTER INSERT OR UPDATE OR DELETE ON bookings
    FOR EACH ROW EXECUTE FUNCTION log_data_change();

CREATE TRIGGER payments_audit_trigger
    AFTER INSERT OR UPDATE OR DELETE ON payments
    FOR EACH ROW EXECUTE FUNCTION log_data_change();

CREATE TRIGGER trip_inventory_audit_trigger
    AFTER INSERT OR UPDATE OR DELETE ON trip_inventory
    FOR EACH ROW EXECUTE FUNCTION log_data_change();

CREATE TRIGGER user_sessions_audit_trigger
    AFTER INSERT OR UPDATE OR DELETE ON user_sessions
    FOR EACH ROW EXECUTE FUNCTION log_data_change();

-- Function to set application context
CREATE OR REPLACE FUNCTION set_app_context(
    p_user_id INTEGER,
    p_user_role VARCHAR(50),
    p_session_id VARCHAR(255) DEFAULT NULL
)
RETURNS VOID AS $$
BEGIN
    PERFORM set_config('app.user_id', p_user_id::TEXT, false);
    PERFORM set_config('app.user_role', p_user_role, false);
    IF p_session_id IS NOT NULL THEN
        PERFORM set_config('app.session_id', p_session_id, false);
    END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to clear application context
CREATE OR REPLACE FUNCTION clear_app_context()
RETURNS VOID AS $$
BEGIN
    PERFORM set_config('app.user_id', '', false);
    PERFORM set_config('app.user_role', '', false);
    PERFORM set_config('app.session_id', '', false);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to check user permissions
CREATE OR REPLACE FUNCTION check_user_permission(
    p_required_role VARCHAR(50)
)
RETURNS BOOLEAN AS $$
DECLARE
    current_role VARCHAR(50);
BEGIN
    BEGIN
        current_role := current_setting('app.user_role');
    EXCEPTION WHEN OTHERS THEN
        RETURN FALSE;
    END;
    
    -- Admin has all permissions
    IF current_role = 'admin' THEN
        RETURN TRUE;
    END IF;
    
    -- Check specific role
    RETURN current_role = p_required_role;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create views for common queries with security
CREATE VIEW user_bookings_view AS
SELECT 
    b.booking_id,
    b.booking_reference,
    b.booking_date,
    b.travel_date,
    b.return_date,
    b.num_travelers,
    b.total_amount,
    b.booking_status,
    b.payment_status,
    b.special_requests,
    t.trip_name,
    t.resort_name,
    t.price_per_person
FROM bookings b
JOIN trip_inventory t ON b.trip_code = t.trip_code
WHERE b.user_id = current_setting('app.user_id')::INTEGER
   OR current_setting('app.user_role') IN ('admin', 'manager');

-- Grant permissions on views
GRANT SELECT ON user_bookings_view TO travlr_app, travlr_admin, travlr_readonly;

-- Create materialized view for analytics (admin only)
CREATE MATERIALIZED VIEW booking_analytics AS
SELECT 
    DATE_TRUNC('month', booking_date) as month,
    COUNT(*) as total_bookings,
    SUM(total_amount) as total_revenue,
    AVG(total_amount) as avg_booking_value,
    COUNT(DISTINCT user_id) as unique_customers,
    COUNT(CASE WHEN booking_status = 'confirmed' THEN 1 END) as confirmed_bookings,
    COUNT(CASE WHEN booking_status = 'cancelled' THEN 1 END) as cancelled_bookings
FROM bookings
GROUP BY DATE_TRUNC('month', booking_date)
ORDER BY month DESC;

-- Create index on materialized view
CREATE INDEX idx_booking_analytics_month ON booking_analytics(month);

-- Grant permissions on materialized view
GRANT SELECT ON booking_analytics TO travlr_admin;

-- Function to refresh analytics
CREATE OR REPLACE FUNCTION refresh_booking_analytics()
RETURNS VOID AS $$
BEGIN
    REFRESH MATERIALIZED VIEW booking_analytics;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute permission
GRANT EXECUTE ON FUNCTION refresh_booking_analytics() TO travlr_admin;
