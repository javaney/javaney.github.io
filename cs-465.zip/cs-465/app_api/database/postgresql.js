/**
 * PostgreSQL Database Connection Pool and Service
 * Implements connection pooling, prepared statements, and query optimization
 */

const { Pool } = require('pg');
const crypto = require('crypto');

class PostgreSQLService {
    constructor() {
        this.pool = null;
        this.isConnected = false;
        this.connectionStats = {
            totalConnections: 0,
            activeConnections: 0,
            idleConnections: 0,
            waitingClients: 0
        };
    }

    /**
     * Initialize PostgreSQL connection pool
     */
    async initialize() {
        try {
            this.pool = new Pool({
                host: process.env.POSTGRES_HOST || 'localhost',
                port: process.env.POSTGRES_PORT || 5432,
                database: process.env.POSTGRES_DB || 'travlr_bookings',
                user: process.env.POSTGRES_USER || 'travlr_app',
                password: process.env.POSTGRES_PASSWORD,
                max: parseInt(process.env.POSTGRES_MAX_CONNECTIONS) || 20,
                min: parseInt(process.env.POSTGRES_MIN_CONNECTIONS) || 5,
                idleTimeoutMillis: parseInt(process.env.POSTGRES_IDLE_TIMEOUT) || 30000,
                connectionTimeoutMillis: parseInt(process.env.POSTGRES_CONNECTION_TIMEOUT) || 5000,
                ssl: process.env.NODE_ENV === 'production' ? {
                    rejectUnauthorized: false,
                    ca: process.env.POSTGRES_CA_CERT
                } : false,
                application_name: 'travlr-api'
            });

            // Set up event handlers
            this.pool.on('error', (err, client) => {
                console.error('Unexpected error on idle PostgreSQL client', err);
                this.isConnected = false;
            });

            this.pool.on('connect', (client) => {
                console.log('New PostgreSQL client connected');
                this.connectionStats.totalConnections++;
            });

            this.pool.on('remove', (client) => {
                console.log('PostgreSQL client removed from pool');
            });

            // Test connection
            const client = await this.pool.connect();
            await client.query('SELECT NOW()');
            client.release();
            
            this.isConnected = true;
            console.log('PostgreSQL connection pool initialized successfully');
            
            // Start monitoring
            this.startMonitoring();
            
        } catch (error) {
            console.error('Failed to initialize PostgreSQL connection pool:', error);
            throw error;
        }
    }

    /**
     * Execute a query with prepared statement
     * @param {string} query - SQL query with parameter placeholders
     * @param {Array} params - Query parameters
     * @param {Object} options - Query options
     * @returns {Promise<Object>} Query result
     */
    async query(query, params = [], options = {}) {
        if (!this.isConnected) {
            throw new Error('PostgreSQL connection pool not initialized');
        }

        const startTime = Date.now();
        let client;

        try {
            client = await this.pool.connect();
            
            // Set application context if provided
            if (options.userId && options.userRole) {
                await client.query('SELECT set_app_context($1, $2, $3)', [
                    options.userId, 
                    options.userRole, 
                    options.sessionId || null
                ]);
            }

            const result = await client.query(query, params);
            
            // Log slow queries
            const duration = Date.now() - startTime;
            if (duration > 1000) { // Log queries taking more than 1 second
                console.warn(`Slow query detected (${duration}ms):`, query.substring(0, 100));
            }

            return {
                rows: result.rows,
                rowCount: result.rowCount,
                duration: duration,
                command: result.command
            };

        } catch (error) {
            console.error('PostgreSQL query error:', error);
            throw new Error(`Database query failed: ${error.message}`);
        } finally {
            if (client) {
                client.release();
            }
        }
    }

    /**
     * Execute a transaction
     * @param {Function} callback - Transaction callback function
     * @param {Object} options - Transaction options
     * @returns {Promise<Object>} Transaction result
     */
    async transaction(callback, options = {}) {
        if (!this.isConnected) {
            throw new Error('PostgreSQL connection pool not initialized');
        }

        const client = await this.pool.connect();
        
        try {
            await client.query('BEGIN');
            
            // Set application context if provided
            if (options.userId && options.userRole) {
                await client.query('SELECT set_app_context($1, $2, $3)', [
                    options.userId, 
                    options.userRole, 
                    options.sessionId || null
                ]);
            }

            const result = await callback(client);
            await client.query('COMMIT');
            
            return result;

        } catch (error) {
            await client.query('ROLLBACK');
            console.error('PostgreSQL transaction error:', error);
            throw new Error(`Database transaction failed: ${error.message}`);
        } finally {
            client.release();
        }
    }

    /**
     * Get user bookings with security context
     * @param {number} userId - User ID
     * @param {Object} options - Query options
     * @returns {Promise<Array>} User bookings
     */
    async getUserBookings(userId, options = {}) {
        const query = `
            SELECT 
                b.booking_id,
                b.booking_reference,
                b.booking_date,
                b.travel_date,
                b.return_date,
                b.num_travelers,
                b.total_amount,
                b.booking_status,
                b.payment_status,
                b.special_requests,
                t.trip_name,
                t.resort_name,
                t.price_per_person,
                p.payment_method,
                p.transaction_id
            FROM bookings b
            JOIN trip_inventory t ON b.trip_code = t.trip_code
            LEFT JOIN payments p ON b.booking_id = p.booking_id
            WHERE b.user_id = $1
            ORDER BY b.booking_date DESC
            LIMIT $2 OFFSET $3
        `;

        const limit = options.limit || 10;
        const offset = (options.page - 1) * limit || 0;

        return await this.query(query, [userId, limit, offset], {
            userId: userId,
            userRole: 'customer'
        });
    }

    /**
     * Create a new booking
     * @param {Object} bookingData - Booking data
     * @param {Object} options - Transaction options
     * @returns {Promise<Object>} Created booking
     */
    async createBooking(bookingData, options = {}) {
        return await this.transaction(async (client) => {
            // Insert booking
            const bookingQuery = `
                INSERT INTO bookings (
                    user_id, trip_code, travel_date, return_date, 
                    num_travelers, total_amount, special_requests, 
                    emergency_contact
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                RETURNING *
            `;

            const bookingResult = await client.query(bookingQuery, [
                bookingData.userId,
                bookingData.tripCode,
                bookingData.travelDate,
                bookingData.returnDate,
                bookingData.numTravelers,
                bookingData.totalAmount,
                bookingData.specialRequests,
                JSON.stringify(bookingData.emergencyContact)
            ]);

            // Update trip inventory
            const inventoryQuery = `
                UPDATE trip_inventory 
                SET available_spots = available_spots - $1,
                    updated_at = CURRENT_TIMESTAMP
                WHERE trip_code = $2 AND available_spots >= $1
            `;

            const inventoryResult = await client.query(inventoryQuery, [
                bookingData.numTravelers,
                bookingData.tripCode
            ]);

            if (inventoryResult.rowCount === 0) {
                throw new Error('Insufficient spots available for this trip');
            }

            return bookingResult.rows[0];
        }, options);
    }

    /**
     * Process payment
     * @param {Object} paymentData - Payment data
     * @param {Object} options - Transaction options
     * @returns {Promise<Object>} Payment result
     */
    async processPayment(paymentData, options = {}) {
        return await this.transaction(async (client) => {
            // Insert payment
            const paymentQuery = `
                INSERT INTO payments (
                    booking_id, amount, payment_method, 
                    transaction_id, payment_status, currency,
                    processor_response
                ) VALUES ($1, $2, $3, $4, $5, $6, $7)
                RETURNING *
            `;

            const paymentResult = await client.query(paymentQuery, [
                paymentData.bookingId,
                paymentData.amount,
                paymentData.paymentMethod,
                paymentData.transactionId,
                paymentData.paymentStatus || 'completed',
                paymentData.currency || 'USD',
                JSON.stringify(paymentData.processorResponse)
            ]);

            // Update booking payment status
            const bookingQuery = `
                UPDATE bookings 
                SET payment_status = $1, updated_at = CURRENT_TIMESTAMP
                WHERE booking_id = $2
            `;

            await client.query(bookingQuery, [
                paymentData.paymentStatus || 'paid',
                paymentData.bookingId
            ]);

            return paymentResult.rows[0];
        }, options);
    }

    /**
     * Get booking analytics
     * @param {Object} options - Query options
     * @returns {Promise<Array>} Analytics data
     */
    async getBookingAnalytics(options = {}) {
        const query = `
            WITH daily_bookings AS (
                SELECT 
                    DATE(booking_date) as booking_day,
                    COUNT(*) as booking_count,
                    SUM(total_amount) as daily_revenue,
                    AVG(num_travelers) as avg_travelers
                FROM bookings
                WHERE booking_date BETWEEN $1 AND $2
                GROUP BY DATE(booking_date)
            ),
            payment_summary AS (
                SELECT 
                    payment_method,
                    COUNT(*) as transaction_count,
                    SUM(amount) as payment_total
                FROM payments
                WHERE payment_date BETWEEN $1 AND $2
                GROUP BY payment_method
            )
            SELECT 
                db.booking_day,
                db.booking_count,
                db.daily_revenue,
                db.avg_travelers,
                ps.payment_method,
                ps.transaction_count
            FROM daily_bookings db
            CROSS JOIN payment_summary ps
            ORDER BY db.booking_day DESC
        `;

        const startDate = options.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
        const endDate = options.endDate || new Date();

        return await this.query(query, [startDate, endDate], {
            userId: options.userId,
            userRole: 'admin'
        });
    }

    /**
     * Start connection monitoring
     */
    startMonitoring() {
        setInterval(() => {
            if (this.pool) {
                this.connectionStats = {
                    totalConnections: this.pool.totalCount,
                    activeConnections: this.pool.totalCount - this.pool.idleCount,
                    idleConnections: this.pool.idleCount,
                    waitingClients: this.pool.waitingCount
                };
            }
        }, 5000); // Update every 5 seconds
    }

    /**
     * Get connection statistics
     * @returns {Object} Connection statistics
     */
    getStats() {
        return {
            isConnected: this.isConnected,
            ...this.connectionStats,
            timestamp: new Date().toISOString()
        };
    }

    /**
     * Health check
     * @returns {Promise<Object>} Health status
     */
    async healthCheck() {
        try {
            const result = await this.query('SELECT NOW() as current_time, version() as postgres_version');
            return {
                status: 'healthy',
                database: 'postgresql',
                timestamp: result.rows[0].current_time,
                version: result.rows[0].postgres_version,
                ...this.getStats()
            };
        } catch (error) {
            return {
                status: 'unhealthy',
                database: 'postgresql',
                error: error.message,
                timestamp: new Date().toISOString()
            };
        }
    }

    /**
     * Close connection pool
     */
    async close() {
        if (this.pool) {
            await this.pool.end();
            this.isConnected = false;
            console.log('PostgreSQL connection pool closed');
        }
    }
}

// Create singleton instance
const postgresService = new PostgreSQLService();

module.exports = postgresService;
