const { body, param, validationResult } = require('express-validator');
const mongoSanitize = require('express-mongo-sanitize');

// Generic validation error handler
const handleValidationErrors = (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            message: 'Validation failed',
            errors: errors.array()
        });
    }
    next();
};

// Trip validation rules
const validateTrip = [
    body('code')
        .trim()
        .isLength({ min: 3, max: 10 })
        .matches(/^[A-Z0-9]+$/)
        .withMessage('Trip code must be 3-10 characters, alphanumeric uppercase only'),
    body('name')
        .trim()
        .isLength({ min: 3, max: 100 })
        .escape()
        .withMessage('Trip name must be 3-100 characters'),
    body('length')
        .trim()
        .isLength({ min: 1, max: 50 })
        .escape()
        .withMessage('Trip length is required and must be less than 50 characters'),
    body('start')
        .isISO8601()
        .toDate()
        .withMessage('Start date must be a valid date'),
    body('resort')
        .trim()
        .isLength({ min: 3, max: 100 })
        .escape()
        .withMessage('Resort name must be 3-100 characters'),
    body('perPerson')
        .isNumeric({ no_symbols: false })
        .isFloat({ min: 0 })
        .withMessage('Price per person must be a positive number'),
    body('image')
        .trim()
        .isLength({ min: 1, max: 200 })
        .matches(/\.(jpg|jpeg|png|gif|webp)$/i)
        .withMessage('Image must be a valid image file path'),
    body('description')
        .trim()
        .isLength({ min: 10, max: 2000 })
        .escape()
        .withMessage('Description must be 10-2000 characters'),
    handleValidationErrors
];

// Trip update validation (allows partial updates)
const validateTripUpdate = [
    body('code')
        .optional()
        .trim()
        .isLength({ min: 3, max: 10 })
        .matches(/^[A-Z0-9]+$/)
        .withMessage('Trip code must be 3-10 characters, alphanumeric uppercase only'),
    body('name')
        .optional()
        .trim()
        .isLength({ min: 3, max: 100 })
        .escape()
        .withMessage('Trip name must be 3-100 characters'),
    body('length')
        .optional()
        .trim()
        .isLength({ min: 1, max: 50 })
        .escape()
        .withMessage('Trip length must be less than 50 characters'),
    body('start')
        .optional()
        .isISO8601()
        .toDate()
        .withMessage('Start date must be a valid date'),
    body('resort')
        .optional()
        .trim()
        .isLength({ min: 3, max: 100 })
        .escape()
        .withMessage('Resort name must be 3-100 characters'),
    body('perPerson')
        .optional()
        .isNumeric({ no_symbols: false })
        .isFloat({ min: 0 })
        .withMessage('Price per person must be a positive number'),
    body('image')
        .optional()
        .trim()
        .isLength({ min: 1, max: 200 })
        .matches(/\.(jpg|jpeg|png|gif|webp)$/i)
        .withMessage('Image must be a valid image file path'),
    body('description')
        .optional()
        .trim()
        .isLength({ min: 10, max: 2000 })
        .escape()
        .withMessage('Description must be 10-2000 characters'),
    handleValidationErrors
];

// User validation rules
const validateUser = [
    body('name')
        .trim()
        .isLength({ min: 2, max: 50 })
        .matches(/^[a-zA-Z\s]+$/)
        .escape()
        .withMessage('Name must be 2-50 characters, letters and spaces only'),
    body('email')
        .trim()
        .isEmail()
        .normalizeEmail()
        .isLength({ max: 100 })
        .withMessage('Must be a valid email address'),
    body('password')
        .isLength({ min: 8, max: 128 })
        .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/)
        .withMessage('Password must be 8-128 characters with at least one lowercase, uppercase, number, and special character'),
    handleValidationErrors
];

// Parameter validation
const validateTripCode = [
    param('tripcode')
        .trim()
        .isLength({ min: 3, max: 10 })
        .matches(/^[A-Z0-9]+$/)
        .withMessage('Trip code must be 3-10 characters, alphanumeric uppercase only'),
    handleValidationErrors
];

const validateTripId = [
    param('tripid')
        .isMongoId()
        .withMessage('Trip ID must be a valid MongoDB ObjectId'),
    handleValidationErrors
];

// Booking validation rules
const validateBooking = [
    body('tripCode')
        .trim()
        .isLength({ min: 3, max: 10 })
        .matches(/^[A-Z0-9]+$/)
        .withMessage('Trip code must be 3-10 characters, alphanumeric uppercase only'),
    body('travelDate')
        .isISO8601()
        .toDate()
        .withMessage('Travel date must be a valid date'),
    body('numTravelers')
        .isInt({ min: 1, max: 20 })
        .withMessage('Number of travelers must be between 1 and 20'),
    body('totalAmount')
        .isFloat({ min: 0 })
        .withMessage('Total amount must be a positive number'),
    body('specialRequests')
        .optional()
        .trim()
        .isLength({ max: 500 })
        .escape()
        .withMessage('Special requests must be less than 500 characters'),
    body('emergencyContact')
        .optional()
        .trim()
        .isLength({ max: 200 })
        .escape()
        .withMessage('Emergency contact must be less than 200 characters'),
    handleValidationErrors
];

const validateBookingUpdate = [
    body('specialRequests')
        .optional()
        .trim()
        .isLength({ max: 500 })
        .escape()
        .withMessage('Special requests must be less than 500 characters'),
    body('emergencyContact')
        .optional()
        .trim()
        .isLength({ max: 200 })
        .escape()
        .withMessage('Emergency contact must be less than 200 characters'),
    handleValidationErrors
];

const validateBookingId = [
    param('bookingId')
        .isInt({ min: 1 })
        .withMessage('Booking ID must be a positive integer'),
    handleValidationErrors
];

// MongoDB injection sanitization middleware
const sanitizeInput = (req, res, next) => {
    // Remove any keys that start with '$' or contain '.'
    mongoSanitize.sanitize(req.body, {
        replaceWith: '_'
    });
    mongoSanitize.sanitize(req.query, {
        replaceWith: '_'
    });
    mongoSanitize.sanitize(req.params, {
        replaceWith: '_'
    });
    next();
};

module.exports = {
    validateTrip,
    validateTripUpdate,
    validateUser,
    validateTripCode,
    validateTripId,
    validateBooking,
    validateBookingUpdate,
    validateBookingId,
    sanitizeInput,
    handleValidationErrors
};
