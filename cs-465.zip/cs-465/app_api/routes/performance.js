const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const performanceService = require('../services/performance.service');
const postgresService = require('../database/postgresql');
// Optional backup service - only load if aws-sdk is available
let BackupService = null;
try {
    BackupService = require('../scripts/backup');
} catch (error) {
    console.warn('Backup service not available - aws-sdk not installed');
}

// JWT Authentication middleware
function authenticateJWT(req, res, next) {
  const authHeader = req.headers['authorization'];
  if(authHeader == null) return res.sendStatus(401);

  const token = authHeader.split(' ')[1];
  if(token == null) return res.sendStatus(401);

  jwt.verify(token, process.env.JWT_SECRET, (err, verified) => {
    if(err) return res.sendStatus(401);
    req.user = verified;
    next();
  });
}

// Admin role check middleware
function requireAdmin(req, res, next) {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Access denied. Admin role required.' });
  }
  next();
}

// GET: /api/performance/metrics - get performance metrics
router.get('/performance/metrics', authenticateJWT, requireAdmin, async (req, res) => {
  try {
    const metrics = await performanceService.getPerformanceMetrics();
    res.status(200).json(metrics);
  } catch (error) {
    console.error('Error getting performance metrics:', error);
    res.status(500).json({
      message: 'Error retrieving performance metrics',
      error: error.message
    });
  }
});

// GET: /api/performance/recommendations - get performance recommendations
router.get('/performance/recommendations', authenticateJWT, requireAdmin, async (req, res) => {
  try {
    const recommendations = await performanceService.getPerformanceRecommendations();
    res.status(200).json({
      recommendations,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error getting performance recommendations:', error);
    res.status(500).json({
      message: 'Error retrieving performance recommendations',
      error: error.message
    });
  }
});

// GET: /api/performance/database-health - get database health status
router.get('/performance/database-health', authenticateJWT, requireAdmin, async (req, res) => {
  try {
    const postgresHealth = await postgresService.healthCheck();
    const mongoHealth = await performanceService.getMongoHealth();
    
    res.status(200).json({
      postgresql: postgresHealth,
      mongodb: mongoHealth,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error getting database health:', error);
    res.status(500).json({
      message: 'Error retrieving database health',
      error: error.message
    });
  }
});

// GET: /api/performance/backup-status - get backup status
router.get('/performance/backup-status', authenticateJWT, requireAdmin, async (req, res) => {
  try {
    if (!BackupService) {
      return res.status(503).json({
        message: 'Backup service not available - aws-sdk not installed',
        backupStatus: { available: false }
      });
    }
    
    const backupService = new BackupService();
    const status = await backupService.getBackupStatus();
    
    res.status(200).json({
      backupStatus: status,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error getting backup status:', error);
    res.status(500).json({
      message: 'Error retrieving backup status',
      error: error.message
    });
  }
});

// POST: /api/performance/backup - trigger manual backup
router.post('/performance/backup', authenticateJWT, requireAdmin, async (req, res) => {
  try {
    if (!BackupService) {
      return res.status(503).json({
        message: 'Backup service not available - aws-sdk not installed'
      });
    }
    
    const backupService = new BackupService();
    const result = await backupService.performFullBackup();
    
    res.status(200).json({
      message: 'Backup initiated successfully',
      result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error initiating backup:', error);
    res.status(500).json({
      message: 'Error initiating backup',
      error: error.message
    });
  }
});

// GET: /api/performance/query-stats - get query performance statistics
router.get('/performance/query-stats', authenticateJWT, requireAdmin, async (req, res) => {
  try {
    const queryStats = performanceService.calculateQueryStats();
    const responseStats = performanceService.calculateResponseStats();
    
    res.status(200).json({
      queries: queryStats,
      responses: responseStats,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error getting query stats:', error);
    res.status(500).json({
      message: 'Error retrieving query statistics',
      error: error.message
    });
  }
});

// GET: /api/performance/connection-stats - get connection statistics
router.get('/performance/connection-stats', authenticateJWT, requireAdmin, async (req, res) => {
  try {
    const connectionStats = performanceService.getConnectionStats();
    
    res.status(200).json({
      connections: connectionStats,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error getting connection stats:', error);
    res.status(500).json({
      message: 'Error retrieving connection statistics',
      error: error.message
    });
  }
});

module.exports = router;
