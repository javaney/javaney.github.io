const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const tripsController = require('../controllers/trips');
const { validateTrip, validateTripUpdate, validateTripCode, validateTripId, sanitizeInput } = require('../middleware/validation');
const { tripModifyLimiter } = require('../middleware/security');

// JWT Authentication middleware with user extraction
function authenticateJWT(req, res, next) {
  const authHeader = req.headers['authorization'];
  if(authHeader == null) return res.sendStatus(401);

  const token = authHeader.split(' ')[1];
  if(token == null) return res.sendStatus(401);

  jwt.verify(token, process.env.JWT_SECRET, (err, verified) => {
    if(err) return res.sendStatus(401);
    req.auth = verified;
    req.user = verified; // Add user to request for audit logging
    next();
  });
}

// Apply input sanitization to all routes
router.use(sanitizeInput);

// GET: /api/trips - list all trips
router.get('/trips', tripsController.tripsList);

// GET: /api/trips/:tripid - get a single trip by ID
router.get('/trips/:tripid', validateTripId, tripsController.tripsReadOne);

// GET: /api/trips/code/:tripcode - get a single trip by code
router.get('/trips/code/:tripcode', validateTripCode, tripsController.tripsFindCode);

// GET: /api/trips/search/suggestions - get search suggestions
router.get('/trips/search/suggestions', tripsController.tripsSearchSuggestions);

// GET: /api/trips/autocomplete - get autocomplete suggestions using Trie
router.get('/trips/autocomplete', tripsController.tripsAutocomplete);

// GET: /api/trips/recommendations/:userId - get personalized recommendations
router.get('/trips/recommendations/:userId', tripsController.tripsGetRecommendations);

// GET: /api/trips/performance-stats - get performance statistics
router.get('/trips/performance-stats', tripsController.tripsGetPerformanceStats);

// POST: /api/trips - add a new trip (protected)
router.post('/trips', tripModifyLimiter, authenticateJWT, validateTrip, tripsController.tripsAddTrip);

// PUT: /api/trips/:tripcode - update a trip by code (protected)
router.put('/trips/:tripcode', tripModifyLimiter, authenticateJWT, validateTripCode, validateTripUpdate, tripsController.tripsUpdateTrip);

// DELETE: /api/trips/:tripcode - delete a trip by code (protected)
router.delete('/trips/:tripcode', tripModifyLimiter, authenticateJWT, validateTripCode, tripsController.tripsDeleteTrip);

module.exports = router;
