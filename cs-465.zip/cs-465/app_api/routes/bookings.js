const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const bookingsController = require('../controllers/bookings');
const { validateBooking, validateBookingUpdate, validateBookingId, sanitizeInput } = require('../middleware/validation');
const { tripModifyLimiter } = require('../middleware/security');

// JWT Authentication middleware
function authenticateJWT(req, res, next) {
  const authHeader = req.headers['authorization'];
  if(authHeader == null) return res.sendStatus(401);

  const token = authHeader.split(' ')[1];
  if(token == null) return res.sendStatus(401);

  jwt.verify(token, process.env.JWT_SECRET, (err, verified) => {
    if(err) return res.sendStatus(401);
    req.user = verified;
    next();
  });
}

// Apply input sanitization to all routes
router.use(sanitizeInput);

// GET: /api/bookings - get user bookings
router.get('/bookings', authenticateJWT, bookingsController.getUserBookings);

// GET: /api/bookings/analytics - get booking analytics (admin only)
router.get('/bookings/analytics', authenticateJWT, bookingsController.getBookingAnalytics);

// POST: /api/bookings - create new booking
router.post('/bookings', tripModifyLimiter, authenticateJWT, validateBooking, bookingsController.createBooking);

// GET: /api/bookings/:bookingId - get specific booking
router.get('/bookings/:bookingId', authenticateJWT, validateBookingId, bookingsController.getBooking);

// PUT: /api/bookings/:bookingId - update booking
router.put('/bookings/:bookingId', tripModifyLimiter, authenticateJWT, validateBookingId, validateBookingUpdate, bookingsController.updateBooking);

// DELETE: /api/bookings/:bookingId - cancel booking
router.delete('/bookings/:bookingId', tripModifyLimiter, authenticateJWT, validateBookingId, bookingsController.cancelBooking);

// POST: /api/bookings/:bookingId/payment - process payment
router.post('/bookings/:bookingId/payment', tripModifyLimiter, authenticateJWT, validateBookingId, bookingsController.processPayment);

module.exports = router;
