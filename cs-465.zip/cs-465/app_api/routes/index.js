const express = require('express');
const router = express.Router();
const tripsRouter = require('./trips');
const bookingsRouter = require('./bookings');
const performanceRouter = require('./performance');
const authController = require('../controllers/authentication');
const { authLimiter } = require('../middleware/security');
const { validateUser, sanitizeInput } = require('../middleware/validation');

// Enable CORS for all API routes with environment-specific origins
router.use('/api', (req, res, next) => {
  // Define allowed origins based on environment
  const allowedOrigins = process.env.NODE_ENV === 'production'
    ? (process.env.ALLOWED_ORIGINS || '').split(',')
    : ['http://localhost:4200', 'http://localhost:3002', 'http://127.0.0.1:4200', 'http://127.0.0.1:3002'];

  const origin = req.headers.origin;

  // Check if the origin is allowed
  if (allowedOrigins.includes(origin)) {
    res.header('Access-Control-Allow-Origin', origin);
  }

  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Credentials', 'true');

  // Handle preflight requests
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  next();
});

// Authentication routes with rate limiting and validation
router.route('/api/register').post(authLimiter, sanitizeInput, validateUser, authController.register);
router.route('/api/login').post(authLimiter, sanitizeInput, authController.login);

// Define routes for our API endpoints
router.use('/api', tripsRouter);
router.use('/api', bookingsRouter);
router.use('/api', performanceRouter);

module.exports = router;
