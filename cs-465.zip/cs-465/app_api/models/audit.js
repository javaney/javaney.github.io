const mongoose = require('mongoose');

// Define the audit log schema
const auditSchema = new mongoose.Schema({
    timestamp: {
        type: Date,
        default: Date.now,
        required: true
    },
    action: {
        type: String,
        required: true,
        enum: ['CREATE_TRIP', 'UPDATE_TRIP', 'DELETE_TRIP', 'LOGIN', 'REGISTER', 'FAILED_LOGIN']
    },
    userId: {
        type: String,
        required: true
    },
    userEmail: {
        type: String,
        required: false
    },
    resourceType: {
        type: String,
        required: true,
        enum: ['TRIP', 'USER', 'AUTH']
    },
    resourceId: {
        type: String,
        required: false
    },
    resourceCode: {
        type: String,
        required: false
    },
    ipAddress: {
        type: String,
        required: false
    },
    userAgent: {
        type: String,
        required: false
    },
    details: {
        type: mongoose.Schema.Types.Mixed,
        required: false
    },
    success: {
        type: Boolean,
        default: true
    },
    errorMessage: {
        type: String,
        required: false
    }
});

// Create indexes for efficient querying
auditSchema.index({ timestamp: -1 });
auditSchema.index({ action: 1, timestamp: -1 });
auditSchema.index({ userId: 1, timestamp: -1 });
auditSchema.index({ resourceType: 1, resourceId: 1, timestamp: -1 });

// Compile the schema into a model
const AuditLog = mongoose.models.AuditLog || mongoose.model('AuditLog', auditSchema);

module.exports = AuditLog;
