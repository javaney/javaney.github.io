const mongoose = require('mongoose');

// Define the trip schema
const tripSchema = new mongoose.Schema({
    code: {
        type: String,
        required: true,
        index: true
    },
    name: {
        type: String,
        required: true,
        index: true
    },
    length: {
        type: String,
        required: true
    },
    start: {
        type: Date,
        required: true
    },
    resort: {
        type: String,
        required: true
    },
    perPerson: {
        type: Number,
        required: true,
        min: 0
    },
    image: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    }
});

// Create text index for search functionality
tripSchema.index({
    name: 'text',
    description: 'text',
    resort: 'text'
}, {
    weights: {
        name: 10,
        resort: 5,
        description: 1
    },
    name: 'trip_text_index'
});

// Create compound indexes for common queries
tripSchema.index({ code: 1, name: 1 });
tripSchema.index({ perPerson: 1, start: 1 });
tripSchema.index({ resort: 1, start: 1 });

// Compile the schema into a model, avoiding overwrite error
const Trip = mongoose.models.Trip || mongoose.model('Trip', tripSchema);

module.exports = Trip;
