const AuditLog = require('../models/audit');

class AuditService {
    /**
     * Log an audit event
     * @param {Object} auditData - The audit data
     * @param {string} auditData.action - The action performed
     * @param {string} auditData.userId - The user ID
     * @param {string} auditData.resourceType - The type of resource
     * @param {Object} req - Express request object (optional)
     * @param {Object} additionalData - Additional data to log
     */
    static async logEvent(auditData, req = null, additionalData = {}) {
        try {
            const logEntry = {
                action: auditData.action,
                userId: auditData.userId || 'anonymous',
                resourceType: auditData.resourceType,
                resourceId: auditData.resourceId,
                resourceCode: auditData.resourceCode,
                userEmail: auditData.userEmail,
                success: auditData.success !== false, // Default to true unless explicitly false
                errorMessage: auditData.errorMessage,
                details: additionalData
            };

            // Extract request information if available
            if (req) {
                logEntry.ipAddress = req.ip || req.connection.remoteAddress;
                logEntry.userAgent = req.get('User-Agent');
            }

            const audit = new AuditLog(logEntry);
            await audit.save();
            
            // Also log to console for immediate visibility
            console.log(`[AUDIT] ${new Date().toISOString()} - ${auditData.action} by ${auditData.userId} on ${auditData.resourceType}${auditData.resourceId ? ':' + auditData.resourceId : ''}`);
            
        } catch (error) {
            // Don't let audit logging failures break the main application
            console.error('Audit logging failed:', error.message);
        }
    }

    /**
     * Log trip-related events
     */
    static async logTripEvent(action, tripData, userId, req = null, success = true, errorMessage = null) {
        await this.logEvent({
            action,
            userId,
            resourceType: 'TRIP',
            resourceId: tripData._id,
            resourceCode: tripData.code,
            success,
            errorMessage
        }, req, {
            tripName: tripData.name,
            changes: tripData.changes || []
        });
    }

    /**
     * Log authentication events
     */
    static async logAuthEvent(action, userData, req = null, success = true, errorMessage = null) {
        await this.logEvent({
            action,
            userId: userData._id || userData.email || 'unknown',
            userEmail: userData.email,
            resourceType: 'AUTH',
            success,
            errorMessage
        }, req, {
            email: userData.email,
            name: userData.name
        });
    }

    /**
     * Get audit logs with filtering and pagination
     */
    static async getAuditLogs(filters = {}, page = 1, limit = 50) {
        try {
            const query = {};
            
            // Apply filters
            if (filters.action) query.action = filters.action;
            if (filters.userId) query.userId = filters.userId;
            if (filters.resourceType) query.resourceType = filters.resourceType;
            if (filters.startDate || filters.endDate) {
                query.timestamp = {};
                if (filters.startDate) query.timestamp.$gte = new Date(filters.startDate);
                if (filters.endDate) query.timestamp.$lte = new Date(filters.endDate);
            }

            const skip = (page - 1) * limit;
            
            const logs = await AuditLog.find(query)
                .sort({ timestamp: -1 })
                .skip(skip)
                .limit(limit)
                .lean();

            const total = await AuditLog.countDocuments(query);

            return {
                logs,
                pagination: {
                    page,
                    limit,
                    total,
                    pages: Math.ceil(total / limit)
                }
            };
        } catch (error) {
            console.error('Error retrieving audit logs:', error.message);
            throw error;
        }
    }

    /**
     * Clean up old audit logs (for maintenance)
     */
    static async cleanupOldLogs(daysToKeep = 90) {
        try {
            const cutoffDate = new Date();
            cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);
            
            const result = await AuditLog.deleteMany({
                timestamp: { $lt: cutoffDate }
            });
            
            console.log(`Cleaned up ${result.deletedCount} old audit log entries`);
            return result.deletedCount;
        } catch (error) {
            console.error('Error cleaning up audit logs:', error.message);
            throw error;
        }
    }
}

module.exports = AuditService;
