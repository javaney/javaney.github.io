/**
 * Performance Monitoring and Analytics Service
 * Tracks database performance, query metrics, and system health
 */

const postgresService = require('../database/postgresql');
const mongoose = require('mongoose');

class PerformanceService {
    constructor() {
        this.metrics = {
            queries: [],
            connections: [],
            errors: [],
            responseTimes: []
        };
        this.startTime = Date.now();
    }

    /**
     * Track query performance
     * @param {string} query - SQL query
     * @param {Array} params - Query parameters
     * @param {number} duration - Query duration in ms
     * @param {string} database - Database type (postgresql/mongodb)
     */
    trackQuery(query, params, duration, database = 'postgresql') {
        const metric = {
            query: query.substring(0, 100), // Truncate for storage
            params: params ? params.length : 0,
            duration: duration,
            database: database,
            timestamp: new Date().toISOString()
        };

        this.metrics.queries.push(metric);

        // Keep only last 1000 queries
        if (this.metrics.queries.length > 1000) {
            this.metrics.queries = this.metrics.queries.slice(-1000);
        }

        // Log slow queries
        if (duration > 1000) {
            console.warn(`Slow query detected (${duration}ms):`, query.substring(0, 100));
        }
    }

    /**
     * Track connection metrics
     * @param {string} database - Database type
     * @param {Object} stats - Connection statistics
     */
    trackConnections(database, stats) {
        const metric = {
            database: database,
            ...stats,
            timestamp: new Date().toISOString()
        };

        this.metrics.connections.push(metric);

        // Keep only last 100 connection records
        if (this.metrics.connections.length > 100) {
            this.metrics.connections = this.metrics.connections.slice(-100);
        }
    }

    /**
     * Track error
     * @param {Error} error - Error object
     * @param {string} context - Error context
     * @param {string} database - Database type
     */
    trackError(error, context, database = 'postgresql') {
        const errorMetric = {
            message: error.message,
            stack: error.stack,
            context: context,
            database: database,
            timestamp: new Date().toISOString()
        };

        this.metrics.errors.push(errorMetric);

        // Keep only last 100 errors
        if (this.metrics.errors.length > 100) {
            this.metrics.errors = this.metrics.errors.slice(-100);
        }
    }

    /**
     * Track response time
     * @param {string} endpoint - API endpoint
     * @param {number} duration - Response duration in ms
     * @param {number} statusCode - HTTP status code
     */
    trackResponseTime(endpoint, duration, statusCode) {
        const metric = {
            endpoint: endpoint,
            duration: duration,
            statusCode: statusCode,
            timestamp: new Date().toISOString()
        };

        this.metrics.responseTimes.push(metric);

        // Keep only last 500 response times
        if (this.metrics.responseTimes.length > 500) {
            this.metrics.responseTimes = this.metrics.responseTimes.slice(-500);
        }
    }

    /**
     * Get comprehensive performance metrics
     * @returns {Promise<Object>} Performance metrics
     */
    async getPerformanceMetrics() {
        try {
            const uptime = Date.now() - this.startTime;
            
            // Get database health
            const postgresHealth = await postgresService.healthCheck();
            const mongoHealth = await this.getMongoHealth();

            // Calculate query statistics
            const queryStats = this.calculateQueryStats();
            
            // Calculate response time statistics
            const responseStats = this.calculateResponseStats();

            // Get error statistics
            const errorStats = this.calculateErrorStats();

            return {
                system: {
                    uptime: uptime,
                    uptimeFormatted: this.formatUptime(uptime),
                    timestamp: new Date().toISOString()
                },
                databases: {
                    postgresql: postgresHealth,
                    mongodb: mongoHealth
                },
                queries: queryStats,
                responses: responseStats,
                errors: errorStats,
                connections: this.getConnectionStats()
            };
        } catch (error) {
            console.error('Error getting performance metrics:', error);
            return {
                error: 'Failed to retrieve performance metrics',
                timestamp: new Date().toISOString()
            };
        }
    }

    /**
     * Get MongoDB health status
     * @returns {Promise<Object>} MongoDB health
     */
    async getMongoHealth() {
        try {
            const startTime = Date.now();
            await mongoose.connection.db.admin().ping();
            const duration = Date.now() - startTime;

            return {
                status: 'healthy',
                database: 'mongodb',
                responseTime: duration,
                timestamp: new Date().toISOString(),
                connectionState: mongoose.connection.readyState
            };
        } catch (error) {
            return {
                status: 'unhealthy',
                database: 'mongodb',
                error: error.message,
                timestamp: new Date().toISOString()
            };
        }
    }

    /**
     * Calculate query statistics
     * @returns {Object} Query statistics
     */
    calculateQueryStats() {
        const queries = this.metrics.queries;
        
        if (queries.length === 0) {
            return {
                total: 0,
                averageDuration: 0,
                slowQueries: 0,
                byDatabase: {}
            };
        }

        const durations = queries.map(q => q.duration);
        const averageDuration = durations.reduce((a, b) => a + b, 0) / durations.length;
        const slowQueries = queries.filter(q => q.duration > 1000).length;

        // Group by database
        const byDatabase = queries.reduce((acc, query) => {
            if (!acc[query.database]) {
                acc[query.database] = { count: 0, totalDuration: 0 };
            }
            acc[query.database].count++;
            acc[query.database].totalDuration += query.duration;
            return acc;
        }, {});

        // Calculate averages per database
        Object.keys(byDatabase).forEach(db => {
            byDatabase[db].averageDuration = byDatabase[db].totalDuration / byDatabase[db].count;
        });

        return {
            total: queries.length,
            averageDuration: Math.round(averageDuration),
            slowQueries: slowQueries,
            slowQueryPercentage: Math.round((slowQueries / queries.length) * 100),
            byDatabase: byDatabase
        };
    }

    /**
     * Calculate response time statistics
     * @returns {Object} Response statistics
     */
    calculateResponseStats() {
        const responses = this.metrics.responseTimes;
        
        if (responses.length === 0) {
            return {
                total: 0,
                averageDuration: 0,
                byEndpoint: {},
                byStatusCode: {}
            };
        }

        const durations = responses.map(r => r.duration);
        const averageDuration = durations.reduce((a, b) => a + b, 0) / durations.length;

        // Group by endpoint
        const byEndpoint = responses.reduce((acc, response) => {
            if (!acc[response.endpoint]) {
                acc[response.endpoint] = { count: 0, totalDuration: 0 };
            }
            acc[response.endpoint].count++;
            acc[response.endpoint].totalDuration += response.duration;
            return acc;
        }, {});

        // Calculate averages per endpoint
        Object.keys(byEndpoint).forEach(endpoint => {
            byEndpoint[endpoint].averageDuration = byEndpoint[endpoint].totalDuration / byEndpoint[endpoint].count;
        });

        // Group by status code
        const byStatusCode = responses.reduce((acc, response) => {
            const code = response.statusCode;
            if (!acc[code]) {
                acc[code] = 0;
            }
            acc[code]++;
            return acc;
        }, {});

        return {
            total: responses.length,
            averageDuration: Math.round(averageDuration),
            byEndpoint: byEndpoint,
            byStatusCode: byStatusCode
        };
    }

    /**
     * Calculate error statistics
     * @returns {Object} Error statistics
     */
    calculateErrorStats() {
        const errors = this.metrics.errors;
        
        if (errors.length === 0) {
            return {
                total: 0,
                byDatabase: {},
                byContext: {}
            };
        }

        // Group by database
        const byDatabase = errors.reduce((acc, error) => {
            acc[error.database] = (acc[error.database] || 0) + 1;
            return acc;
        }, {});

        // Group by context
        const byContext = errors.reduce((acc, error) => {
            acc[error.context] = (acc[error.context] || 0) + 1;
            return acc;
        }, {});

        return {
            total: errors.length,
            byDatabase: byDatabase,
            byContext: byContext
        };
    }

    /**
     * Get connection statistics
     * @returns {Object} Connection statistics
     */
    getConnectionStats() {
        const connections = this.metrics.connections;
        
        if (connections.length === 0) {
            return {
                postgresql: postgresService.getStats(),
                mongodb: {
                    readyState: mongoose.connection.readyState,
                    host: mongoose.connection.host,
                    port: mongoose.connection.port,
                    name: mongoose.connection.name
                }
            };
        }

        const latest = connections[connections.length - 1];
        return {
            postgresql: latest.database === 'postgresql' ? latest : postgresService.getStats(),
            mongodb: latest.database === 'mongodb' ? latest : {
                readyState: mongoose.connection.readyState,
                host: mongoose.connection.host,
                port: mongoose.connection.port,
                name: mongoose.connection.name
            }
        };
    }

    /**
     * Format uptime in human-readable format
     * @param {number} uptime - Uptime in milliseconds
     * @returns {string} Formatted uptime
     */
    formatUptime(uptime) {
        const seconds = Math.floor(uptime / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);

        if (days > 0) {
            return `${days}d ${hours % 24}h ${minutes % 60}m`;
        } else if (hours > 0) {
            return `${hours}h ${minutes % 60}m`;
        } else if (minutes > 0) {
            return `${minutes}m ${seconds % 60}s`;
        } else {
            return `${seconds}s`;
        }
    }

    /**
     * Get database performance recommendations
     * @returns {Promise<Array>} Performance recommendations
     */
    async getPerformanceRecommendations() {
        const recommendations = [];
        const queryStats = this.calculateQueryStats();
        const responseStats = this.calculateResponseStats();

        // Query performance recommendations
        if (queryStats.slowQueryPercentage > 10) {
            recommendations.push({
                type: 'query_performance',
                priority: 'high',
                message: `${queryStats.slowQueryPercentage}% of queries are slow (>1000ms). Consider adding indexes or optimizing queries.`,
                action: 'Review slow queries and add appropriate indexes'
            });
        }

        if (queryStats.averageDuration > 500) {
            recommendations.push({
                type: 'query_performance',
                priority: 'medium',
                message: `Average query duration is ${queryStats.averageDuration}ms. Consider query optimization.`,
                action: 'Analyze query execution plans and optimize slow queries'
            });
        }

        // Response time recommendations
        if (responseStats.averageDuration > 1000) {
            recommendations.push({
                type: 'response_time',
                priority: 'high',
                message: `Average response time is ${responseStats.averageDuration}ms. Consider performance optimization.`,
                action: 'Implement caching and optimize database queries'
            });
        }

        // Connection recommendations
        const connectionStats = this.getConnectionStats();
        if (connectionStats.postgresql.waitingClients > 5) {
            recommendations.push({
                type: 'connection_pool',
                priority: 'medium',
                message: `${connectionStats.postgresql.waitingClients} clients waiting for connections. Consider increasing pool size.`,
                action: 'Increase PostgreSQL connection pool size'
            });
        }

        return recommendations;
    }

    /**
     * Clear old metrics
     */
    clearOldMetrics() {
        const cutoffTime = Date.now() - (24 * 60 * 60 * 1000); // 24 hours ago
        
        this.metrics.queries = this.metrics.queries.filter(q => 
            new Date(q.timestamp).getTime() > cutoffTime
        );
        
        this.metrics.connections = this.metrics.connections.filter(c => 
            new Date(c.timestamp).getTime() > cutoffTime
        );
        
        this.metrics.errors = this.metrics.errors.filter(e => 
            new Date(e.timestamp).getTime() > cutoffTime
        );
        
        this.metrics.responseTimes = this.metrics.responseTimes.filter(r => 
            new Date(r.timestamp).getTime() > cutoffTime
        );
    }
}

// Create singleton instance
const performanceService = new PerformanceService();

// Clear old metrics every hour
setInterval(() => {
    performanceService.clearOldMetrics();
}, 60 * 60 * 1000);

module.exports = performanceService;
