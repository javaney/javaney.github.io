/**
 * Recommendation Engine with Collaborative Filtering
 * Implements cosine similarity calculations and user-based collaborative filtering
 * Supports cold-start scenarios and hybrid recommendation approaches
 */

const LRUCache = require('../utils/lru-cache');
const Trip = require('../models/travlr');
const User = require('../models/user');

class RecommendationEngine {
    constructor() {
        this.userProfiles = new Map();
        this.cache = new LRUCache(500); // Cache recommendations
        this.similarityCache = new LRUCache(200); // Cache user similarities
        this.cacheExpiry = 30 * 60 * 1000; // 30 minutes
    }

    /**
     * Generate recommendations for a user using collaborative filtering
     * @param {string} userId - The user ID
     * @param {number} limit - Maximum number of recommendations
     * @returns {Promise<Array>} Array of recommended trips
     */
    async generateRecommendations(userId, limit = 10) {
        const cacheKey = `recommendations_${userId}_${limit}`;
        const cached = this.cache.get(cacheKey);
        
        if (cached && this._isCacheValid(cached.timestamp)) {
            return cached.recommendations;
        }

        try {
            const userBookings = await this.getUserBookings(userId);
            
            if (userBookings.length === 0) {
                // Cold start - return popular trips
                return await this.getPopularTrips(limit);
            }

            const similarUsers = await this.findSimilarUsers(userId, userBookings);
            
            if (similarUsers.length === 0) {
                // No similar users - return popular trips
                return await this.getPopularTrips(limit);
            }

            const recommendations = await this.calculateRecommendations(
                userId,
                similarUsers,
                userBookings,
                limit
            );

            // Cache the results
            this.cache.put(cacheKey, {
                recommendations,
                timestamp: Date.now()
            });

            return recommendations;
        } catch (error) {
            console.error('Error generating recommendations:', error);
            // Fallback to popular trips
            return await this.getPopularTrips(limit);
        }
    }

    /**
     * Find users similar to the given user based on booking history
     * @param {string} userId - The user ID
     * @param {Array} userBookings - User's booking history
     * @returns {Promise<Array>} Array of similar users with similarity scores
     */
    async findSimilarUsers(userId, userBookings) {
        const cacheKey = `similar_users_${userId}`;
        const cached = this.similarityCache.get(cacheKey);
        
        if (cached && this._isCacheValid(cached.timestamp)) {
            return cached.similarUsers;
        }

        try {
            const allUsers = await this.getAllUserBookings();
            const similarities = [];

            for (const [otherUserId, otherBookings] of allUsers) {
                if (otherUserId === userId) continue;
                
                const similarity = this.cosineSimilarity(userBookings, otherBookings);
                
                if (similarity > 0.3) { // Threshold for similarity
                    similarities.push({ 
                        userId: otherUserId, 
                        similarity,
                        bookingCount: otherBookings.length
                    });
                }
            }

            // Sort by similarity score and take top 20
            const similarUsers = similarities
                .sort((a, b) => b.similarity - a.similarity)
                .slice(0, 20);

            // Cache the results
            this.similarityCache.put(cacheKey, {
                similarUsers,
                timestamp: Date.now()
            });

            return similarUsers;
        } catch (error) {
            console.error('Error finding similar users:', error);
            return [];
        }
    }

    /**
     * Calculate cosine similarity between two booking vectors
     * @param {Array} bookings1 - First user's bookings
     * @param {Array} bookings2 - Second user's bookings
     * @returns {number} Cosine similarity score (0-1)
     */
    cosineSimilarity(bookings1, bookings2) {
        if (bookings1.length === 0 || bookings2.length === 0) {
            return 0;
        }

        // Create sets of trip IDs for each user
        const set1 = new Set(bookings1.map(b => b.tripId || b._id));
        const set2 = new Set(bookings2.map(b => b.tripId || b._id));
        
        // Find intersection
        const intersection = new Set([...set1].filter(x => set2.has(x)));
        
        // Calculate magnitudes
        const magnitude1 = Math.sqrt(set1.size);
        const magnitude2 = Math.sqrt(set2.size);
        
        if (magnitude1 === 0 || magnitude2 === 0) {
            return 0;
        }
        
        return intersection.size / (magnitude1 * magnitude2);
    }

    /**
     * Calculate weighted recommendations based on similar users
     * @param {string} userId - The user ID
     * @param {Array} similarUsers - Array of similar users
     * @param {Array} userBookings - User's current bookings
     * @param {number} limit - Maximum recommendations
     * @returns {Promise<Array>} Array of recommended trips
     */
    async calculateRecommendations(userId, similarUsers, userBookings, limit) {
        const userTripIds = new Set(userBookings.map(b => b.tripId || b._id));
        const tripScores = new Map();

        // Get all trips that similar users have booked
        for (const similarUser of similarUsers) {
            const similarUserBookings = await this.getUserBookings(similarUser.userId);
            
            for (const booking of similarUserBookings) {
                const tripId = booking.tripId || booking._id;
                
                // Skip trips the user has already booked
                if (userTripIds.has(tripId)) continue;
                
                // Calculate weighted score
                const baseScore = similarUser.similarity;
                const recencyWeight = this._calculateRecencyWeight(booking.bookingDate || booking.createdAt);
                const finalScore = baseScore * recencyWeight;
                
                if (tripScores.has(tripId)) {
                    tripScores.set(tripId, tripScores.get(tripId) + finalScore);
                } else {
                    tripScores.set(tripId, finalScore);
                }
            }
        }

        // Sort by score and get top recommendations
        const sortedTrips = Array.from(tripScores.entries())
            .sort((a, b) => b[1] - a[1])
            .slice(0, limit);

        // Get trip details
        const recommendations = [];
        for (const [tripId, score] of sortedTrips) {
            try {
                const trip = await Trip.findById(tripId).lean();
                if (trip) {
                    recommendations.push({
                        ...trip,
                        recommendationScore: score,
                        reason: 'Similar users also booked this trip'
                    });
                }
            } catch (error) {
                console.error(`Error fetching trip ${tripId}:`, error);
            }
        }

        return recommendations;
    }

    /**
     * Get popular trips as fallback recommendations
     * @param {number} limit - Maximum number of trips
     * @returns {Promise<Array>} Array of popular trips
     */
    async getPopularTrips(limit = 10) {
        try {
            const popularTrips = await Trip.aggregate([
                { $sort: { perPerson: 1 } }, // Sort by price as popularity proxy
                { $limit: limit },
                {
                    $addFields: {
                        recommendationScore: 0.5,
                        reason: 'Popular choice'
                    }
                }
            ]);

            return popularTrips;
        } catch (error) {
            console.error('Error getting popular trips:', error);
            return [];
        }
    }

    /**
     * Get user's booking history
     * @param {string} userId - The user ID
     * @returns {Promise<Array>} Array of user bookings
     */
    async getUserBookings(userId) {
        // This would typically come from a bookings collection
        // For now, we'll simulate with a simple approach
        // In a real implementation, you'd query a bookings collection
        return [];
    }

    /**
     * Get all users' booking history
     * @returns {Promise<Map>} Map of userId to bookings
     */
    async getAllUserBookings() {
        // This would typically query a bookings collection
        // For now, return empty map
        return new Map();
    }

    /**
     * Calculate recency weight for a booking
     * @param {Date|string} bookingDate - The booking date
     * @returns {number} Recency weight (0-1)
     */
    _calculateRecencyWeight(bookingDate) {
        if (!bookingDate) return 0.5;
        
        const now = new Date();
        const booking = new Date(bookingDate);
        const daysDiff = (now - booking) / (1000 * 60 * 60 * 24);
        
        // More recent bookings get higher weight
        return Math.max(0.1, 1 - (daysDiff / 365)); // Decay over a year
    }

    /**
     * Check if cache entry is still valid
     * @param {number} timestamp - Cache timestamp
     * @returns {boolean} True if cache is valid
     */
    _isCacheValid(timestamp) {
        return (Date.now() - timestamp) < this.cacheExpiry;
    }

    /**
     * Get recommendation engine statistics
     * @returns {Object} Engine statistics
     */
    getStats() {
        return {
            userProfiles: this.userProfiles.size,
            cacheStats: this.cache.getStats(),
            similarityCacheStats: this.similarityCache.getStats(),
            cacheExpiry: this.cacheExpiry
        };
    }

    /**
     * Clear all caches
     */
    clearCaches() {
        this.cache.clear();
        this.similarityCache.clear();
        this.userProfiles.clear();
    }

    /**
     * Update user profile with new booking
     * @param {string} userId - The user ID
     * @param {Object} booking - The new booking
     */
    updateUserProfile(userId, booking) {
        if (!this.userProfiles.has(userId)) {
            this.userProfiles.set(userId, []);
        }
        
        const profile = this.userProfiles.get(userId);
        profile.push(booking);
        
        // Invalidate related caches
        this.cache.delete(`recommendations_${userId}`);
        this.similarityCache.delete(`similar_users_${userId}`);
    }
}

module.exports = RecommendationEngine;
