const Trip = require('../models/travlr');
const AuditService = require('../services/audit.service');
const { SearchTrie } = require('../utils/trie');
const LRUCache = require('../utils/lru-cache');
const RecommendationEngine = require('../services/recommendation.service');

// Initialize Trie for autocomplete (in production, this would be built from database)
const searchTrie = new SearchTrie();
const tripCache = new LRUCache(1000);
const recommendationEngine = new RecommendationEngine();

// Build Trie from existing trips (in production, this would be done on startup)
const buildTrieFromDatabase = async () => {
    try {
        const trips = await Trip.find({}).lean();
        trips.forEach(trip => {
            searchTrie.insert(trip.name, trip._id.toString());
            searchTrie.insert(trip.resort, trip._id.toString());
        });
        console.log(`Trie built with ${searchTrie.getStats().totalWords} words`);
    } catch (error) {
        console.error('Error building Trie:', error);
    }
};

// Initialize Trie on startup
buildTrieFromDatabase();

// GET: /api/trips - lists all trips with optional search and filtering
const tripsList = async (req, res) => {
    try {
        const searchText = req.query.search;
        const minPrice = req.query.minPrice ? parseFloat(req.query.minPrice) : 0;
        const maxPrice = req.query.maxPrice ? parseFloat(req.query.maxPrice) : 99999;
        const resort = req.query.resort;
        const startDate = req.query.startDate ? new Date(req.query.startDate) : null;
        const endDate = req.query.endDate ? new Date(req.query.endDate) : null;
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const skip = (page - 1) * limit;

        // Build aggregation pipeline for optimized search with relevance scoring
        const pipeline = [];

        // Stage 1: Match stage with all filters
        const matchStage = {};
        
        if (searchText) {
            matchStage.$or = [
                { name: { $regex: searchText, $options: 'i' } },
                { description: { $regex: searchText, $options: 'i' } },
                { resort: { $regex: searchText, $options: 'i' } }
            ];
        }

        if (minPrice > 0 || maxPrice < 99999) {
            matchStage.perPerson = {};
            if (minPrice > 0) matchStage.perPerson.$gte = minPrice;
            if (maxPrice < 99999) matchStage.perPerson.$lte = maxPrice;
        }

        if (resort) {
            matchStage.resort = new RegExp(resort, 'i');
        }

        if (startDate || endDate) {
            matchStage.start = {};
            if (startDate) matchStage.start.$gte = startDate;
            if (endDate) matchStage.start.$lte = endDate;
        }

        if (Object.keys(matchStage).length > 0) {
            pipeline.push({ $match: matchStage });
        }

        // Stage 2: Add relevance scoring for search results
        if (searchText) {
            pipeline.push({
                $addFields: {
                    relevanceScore: {
                        $add: [
                            // Name matches get highest score
                            { $cond: [{ $regexMatch: { input: '$name', regex: searchText, options: 'i' } }, 10, 0] },
                            // Resort matches get medium score
                            { $cond: [{ $regexMatch: { input: '$resort', regex: searchText, options: 'i' } }, 5, 0] },
                            // Description matches get lowest score
                            { $cond: [{ $regexMatch: { input: '$description', regex: searchText, options: 'i' } }, 1, 0] },
                            // Exact name match bonus
                            { $cond: [{ $eq: [{ $toLower: '$name' }, searchText.toLowerCase()] }, 5, 0] },
                            // Starts with search text bonus
                            { $cond: [{ $regexMatch: { input: '$name', regex: `^${searchText}`, options: 'i' } }, 3, 0] }
                        ]
                    }
                }
            });
        } else {
            // No search text - add default relevance score
            pipeline.push({
                $addFields: {
                    relevanceScore: 0
                }
            });
        }

        // Stage 3: Sort by relevance score and price
        const sortStage = {};
        if (searchText) {
            sortStage.relevanceScore = -1; // Higher relevance first
        }
        sortStage.perPerson = 1; // Lower price first
        pipeline.push({ $sort: sortStage });

        // Stage 4: Pagination
        pipeline.push({ $skip: skip });
        pipeline.push({ $limit: limit });

        // Stage 5: Project only needed fields for performance
        pipeline.push({
            $project: {
                _id: 1,
                code: 1,
                name: 1,
                length: 1,
                start: 1,
                resort: 1,
                perPerson: 1,
                image: 1,
                description: 1,
                relevanceScore: 1
            }
        });

        // Execute aggregation pipeline
        const trips = await Trip.aggregate(pipeline);

        // Get total count for pagination (without pagination limits)
        const countPipeline = pipeline.slice(0, -2); // Remove skip and limit
        countPipeline.push({ $count: 'total' });
        const countResult = await Trip.aggregate(countPipeline);
        const total = countResult.length > 0 ? countResult[0].total : 0;

        if (!trips || trips.length === 0) {
            return res.status(404).json({
                "message": "No trips found"
            });
        }

        res.status(200).json({
            trips,
            pagination: {
                page,
                limit,
                total,
                pages: Math.ceil(total / limit)
            },
            searchInfo: searchText ? {
                searchText,
                relevanceScoring: true,
                totalResults: total
            } : null
        });
    } catch (err) {
        console.log(err);
        res.status(500).json({
            "message": "Error retrieving trips",
            "error": err.message
        });
    }
};

// GET: /api/trips/:tripid - returns a single trip
const tripsReadOne = async (req, res) => {
    try {
        const trip = await Trip.findById(req.params.tripid);
        if (!trip) {
            return res.status(404).json({
                "message": "Trip not found"
            });
        }
        res.status(200).json(trip);
    } catch (err) {
        console.log(err);
        res.status(500).json({
            "message": "Error retrieving trip",
            "error": err.message
        });
    }
};

// GET: /api/trips/code/:tripcode - returns a single trip by code
const tripsFindCode = async (req, res) => {
    try {
        const trip = await Trip.findOne({ code: req.params.tripcode });
        if (!trip) {
            return res.status(404).json({
                "message": "Trip not found"
            });
        }
        res.status(200).json(trip);
    } catch (err) {
        console.log(err);
        res.status(500).json({
            "message": "Error retrieving trip",
            "error": err.message
        });
    }
};

// POST: /api/trips - add a new trip
const tripsAddTrip = async (req, res) => {
    try {
        // Convert perPerson to number if it's a string
        if (req.body.perPerson && typeof req.body.perPerson === 'string') {
            req.body.perPerson = parseFloat(req.body.perPerson);
        }

        const newTrip = new Trip(req.body);
        const savedTrip = await newTrip.save();

        // Audit log
        const userId = req.user ? req.user._id : 'unknown';
        await AuditService.logTripEvent('CREATE_TRIP', savedTrip, userId, req);

        res.status(201).json(savedTrip);
    } catch (err) {
        console.log(err);
        res.status(400).json({
            "message": "Error creating trip",
            "error": err.message
        });
    }
};

// PUT: /api/trips/:tripcode - update a trip by code
const tripsUpdateTrip = async (req, res) => {
    try {
        // Convert perPerson to number if it's a string
        if (req.body.perPerson && typeof req.body.perPerson === 'string') {
            req.body.perPerson = parseFloat(req.body.perPerson);
        }

        const trip = await Trip.findOneAndUpdate(
            { 'code': req.params.tripcode },
            req.body,
            { new: true, runValidators: true }
        );
        if (!trip) {
            return res.status(404).json({
                "message": "Trip not found"
            });
        }

        // Audit log
        const userId = req.user ? req.user._id : 'unknown';
        const tripWithChanges = { ...trip.toObject(), changes: Object.keys(req.body) };
        await AuditService.logTripEvent('UPDATE_TRIP', tripWithChanges, userId, req);

        res.status(200).json(trip);
    } catch (err) {
        console.log(err);
        res.status(400).json({
            "message": "Error updating trip",
            "error": err.message
        });
    }
};

// DELETE: /api/trips/:tripcode - delete a trip by code
const tripsDeleteTrip = async (req, res) => {
    try {
        const trip = await Trip.findOneAndDelete({ 'code': req.params.tripcode });
        if (!trip) {
            return res.status(404).json({
                "message": "Trip not found"
            });
        }

        // Audit log
        const userId = req.user ? req.user._id : 'unknown';
        await AuditService.logTripEvent('DELETE_TRIP', trip, userId, req);

        res.status(200).json({
            "message": "Trip deleted successfully"
        });
    } catch (err) {
        console.log(err);
        res.status(500).json({
            "message": "Error deleting trip",
            "error": err.message
        });
    }
};

// GET: /api/trips/search/suggestions - get search suggestions with Trie optimization
const tripsSearchSuggestions = async (req, res) => {
    try {
        const query = req.query.q;
        if (!query || query.length < 2) {
            return res.status(400).json({
                "message": "Query must be at least 2 characters"
            });
        }

        // Enhanced aggregation pipeline with relevance scoring for suggestions
        const suggestions = await Trip.aggregate([
            {
                $match: {
                    $or: [
                        { name: { $regex: query, $options: 'i' } },
                        { resort: { $regex: query, $options: 'i' } },
                        { description: { $regex: query, $options: 'i' } }
                    ]
                }
            },
            {
                $addFields: {
                    relevanceScore: {
                        $add: [
                            // Exact name match gets highest score
                            { $cond: [{ $eq: [{ $toLower: '$name' }, query.toLowerCase()] }, 20, 0] },
                            // Name starts with query gets high score
                            { $cond: [{ $regexMatch: { input: '$name', regex: `^${query}`, options: 'i' } }, 15, 0] },
                            // Name contains query gets medium score
                            { $cond: [{ $regexMatch: { input: '$name', regex: query, options: 'i' } }, 10, 0] },
                            // Resort starts with query gets medium score
                            { $cond: [{ $regexMatch: { input: '$resort', regex: `^${query}`, options: 'i' } }, 8, 0] },
                            // Resort contains query gets lower score
                            { $cond: [{ $regexMatch: { input: '$resort', regex: query, options: 'i' } }, 5, 0] },
                            // Description contains query gets lowest score
                            { $cond: [{ $regexMatch: { input: '$description', regex: query, options: 'i' } }, 1, 0] }
                        ]
                    }
                }
            },
            {
                $project: {
                    _id: 0,
                    suggestion: '$name',
                    type: 'trip',
                    code: '$code',
                    relevanceScore: 1
                }
            },
            {
                $unionWith: {
                    coll: 'trips',
                    pipeline: [
                        {
                            $match: {
                                resort: { $regex: query, $options: 'i' }
                            }
                        },
                        {
                            $addFields: {
                                relevanceScore: {
                                    $add: [
                                        // Resort exact match
                                        { $cond: [{ $eq: [{ $toLower: '$resort' }, query.toLowerCase()] }, 15, 0] },
                                        // Resort starts with query
                                        { $cond: [{ $regexMatch: { input: '$resort', regex: `^${query}`, options: 'i' } }, 10, 0] },
                                        // Resort contains query
                                        { $cond: [{ $regexMatch: { input: '$resort', regex: query, options: 'i' } }, 5, 0] }
                                    ]
                                }
                            }
                        },
                        {
                            $group: {
                                _id: '$resort',
                                count: { $sum: 1 },
                                relevanceScore: { $max: '$relevanceScore' }
                            }
                        },
                        {
                            $project: {
                                _id: 0,
                                suggestion: '$_id',
                                type: 'resort',
                                count: '$count',
                                relevanceScore: 1
                            }
                        }
                    ]
                }
            },
            {
                $sort: {
                    relevanceScore: -1,
                    count: -1
                }
            },
            { $limit: 10 }
        ]);

        res.status(200).json({
            suggestions,
            searchInfo: {
                query,
                totalSuggestions: suggestions.length,
                algorithm: 'enhanced_aggregation_with_relevance_scoring'
            }
        });
    } catch (err) {
        console.log(err);
        res.status(500).json({
            "message": "Error retrieving suggestions",
            "error": err.message
        });
    }
};

// GET: /api/trips/recommendations/:userId - get personalized recommendations
const tripsGetRecommendations = async (req, res) => {
    try {
        const userId = req.params.userId;
        const limit = parseInt(req.query.limit) || 10;

        if (!userId) {
            return res.status(400).json({
                "message": "User ID is required"
            });
        }

        const recommendations = await recommendationEngine.generateRecommendations(userId, limit);

        res.status(200).json({
            recommendations,
            userId,
            algorithm: 'collaborative_filtering_with_cosine_similarity',
            cacheStats: recommendationEngine.getStats()
        });
    } catch (err) {
        console.log(err);
        res.status(500).json({
            "message": "Error generating recommendations",
            "error": err.message
        });
    }
};

// GET: /api/trips/autocomplete - get autocomplete suggestions using Trie
const tripsAutocomplete = async (req, res) => {
    try {
        const query = req.query.q;
        if (!query || query.length < 2) {
            return res.status(400).json({
                "message": "Query must be at least 2 characters"
            });
        }

        // Use Trie for O(m) prefix search
        const tripIds = searchTrie.search(query);
        
        if (tripIds.length === 0) {
            return res.status(200).json({
                suggestions: [],
                searchInfo: {
                    query,
                    algorithm: 'trie_prefix_search',
                    totalSuggestions: 0
                }
            });
        }

        // Get trip details for the found IDs
        const suggestions = await Trip.find({
            _id: { $in: tripIds }
        }).select('name resort code').lean();

        res.status(200).json({
            suggestions: suggestions.map(trip => ({
                suggestion: trip.name,
                type: 'trip',
                code: trip.code,
                resort: trip.resort
            })),
            searchInfo: {
                query,
                algorithm: 'trie_prefix_search',
                totalSuggestions: suggestions.length,
                trieStats: searchTrie.getStats()
            }
        });
    } catch (err) {
        console.log(err);
        res.status(500).json({
            "message": "Error retrieving autocomplete suggestions",
            "error": err.message
        });
    }
};

// GET: /api/trips/performance-stats - get performance statistics
const tripsGetPerformanceStats = async (req, res) => {
    try {
        const stats = {
            trie: searchTrie.getStats(),
            cache: tripCache.getStats(),
            recommendations: recommendationEngine.getStats(),
            timestamp: new Date().toISOString()
        };

        res.status(200).json(stats);
    } catch (err) {
        console.log(err);
        res.status(500).json({
            "message": "Error retrieving performance stats",
            "error": err.message
        });
    }
};

module.exports = {
    tripsList,
    tripsReadOne,
    tripsFindCode,
    tripsAddTrip,
    tripsUpdateTrip,
    tripsDeleteTrip,
    tripsSearchSuggestions,
    tripsGetRecommendations,
    tripsAutocomplete,
    tripsGetPerformanceStats
};
