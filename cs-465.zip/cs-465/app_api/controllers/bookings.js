/**
 * Bookings Controller for Polyglot Persistence
 * Handles booking operations using PostgreSQL for transactional data
 */

const postgresService = require('../database/postgresql');
const AuditService = require('../services/audit.service');

// GET: /api/bookings - get user bookings
const getUserBookings = async (req, res) => {
    try {
        const userId = req.user._id;
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;

        const bookings = await postgresService.getUserBookings(userId, { page, limit });

        // Get total count for pagination
        const countResult = await postgresService.query(
            'SELECT COUNT(*) as total FROM bookings WHERE user_id = $1',
            [userId],
            { userId, userRole: 'customer' }
        );

        const total = parseInt(countResult.rows[0].total);

        res.status(200).json({
            bookings: bookings.rows,
            pagination: {
                page,
                limit,
                total,
                pages: Math.ceil(total / limit)
            }
        });
    } catch (err) {
        console.error('Error retrieving user bookings:', err);
        res.status(500).json({
            message: 'Error retrieving bookings',
            error: err.message
        });
    }
};

// POST: /api/bookings - create new booking
const createBooking = async (req, res) => {
    try {
        const userId = req.user._id;
        const bookingData = {
            userId: userId,
            tripCode: req.body.tripCode,
            travelDate: new Date(req.body.travelDate),
            returnDate: req.body.returnDate ? new Date(req.body.returnDate) : null,
            numTravelers: parseInt(req.body.numTravelers),
            totalAmount: parseFloat(req.body.totalAmount),
            specialRequests: req.body.specialRequests,
            emergencyContact: req.body.emergencyContact
        };

        // Validate required fields
        if (!bookingData.tripCode || !bookingData.travelDate || !bookingData.numTravelers || !bookingData.totalAmount) {
            return res.status(400).json({
                message: 'Missing required fields: tripCode, travelDate, numTravelers, totalAmount'
            });
        }

        const booking = await postgresService.createBooking(bookingData, {
            userId: userId,
            userRole: 'customer'
        });

        // Audit log
        await AuditService.logBookingEvent('CREATE_BOOKING', booking, userId, req);

        res.status(201).json({
            message: 'Booking created successfully',
            booking: {
                bookingId: booking.booking_id,
                bookingReference: booking.booking_reference,
                status: booking.booking_status,
                totalAmount: booking.total_amount
            }
        });
    } catch (err) {
        console.error('Error creating booking:', err);
        res.status(400).json({
            message: 'Error creating booking',
            error: err.message
        });
    }
};

// GET: /api/bookings/:bookingId - get specific booking
const getBooking = async (req, res) => {
    try {
        const bookingId = req.params.bookingId;
        const userId = req.user._id;

        const result = await postgresService.query(`
            SELECT 
                b.*,
                t.trip_name,
                t.resort_name,
                t.price_per_person,
                p.payment_method,
                p.payment_status as payment_status,
                p.transaction_id
            FROM bookings b
            JOIN trip_inventory t ON b.trip_code = t.trip_code
            LEFT JOIN payments p ON b.booking_id = p.booking_id
            WHERE b.booking_id = $1 AND b.user_id = $2
        `, [bookingId, userId], { userId, userRole: 'customer' });

        if (result.rows.length === 0) {
            return res.status(404).json({
                message: 'Booking not found'
            });
        }

        res.status(200).json(result.rows[0]);
    } catch (err) {
        console.error('Error retrieving booking:', err);
        res.status(500).json({
            message: 'Error retrieving booking',
            error: err.message
        });
    }
};

// PUT: /api/bookings/:bookingId - update booking
const updateBooking = async (req, res) => {
    try {
        const bookingId = req.params.bookingId;
        const userId = req.user._id;

        // Only allow updates to pending bookings
        const allowedFields = ['special_requests', 'emergency_contact'];
        const updateFields = {};
        
        for (const field of allowedFields) {
            if (req.body[field] !== undefined) {
                updateFields[field] = req.body[field];
            }
        }

        if (Object.keys(updateFields).length === 0) {
            return res.status(400).json({
                message: 'No valid fields to update'
            });
        }

        const setClause = Object.keys(updateFields).map((field, index) => 
            `${field} = $${index + 2}`
        ).join(', ');

        const values = [bookingId, ...Object.values(updateFields)];

        const result = await postgresService.query(`
            UPDATE bookings 
            SET ${setClause}, updated_at = CURRENT_TIMESTAMP
            WHERE booking_id = $1 AND user_id = $2 AND booking_status = 'pending'
            RETURNING *
        `, values, { userId, userRole: 'customer' });

        if (result.rows.length === 0) {
            return res.status(404).json({
                message: 'Booking not found or cannot be updated'
            });
        }

        // Audit log
        await AuditService.logBookingEvent('UPDATE_BOOKING', result.rows[0], userId, req);

        res.status(200).json({
            message: 'Booking updated successfully',
            booking: result.rows[0]
        });
    } catch (err) {
        console.error('Error updating booking:', err);
        res.status(400).json({
            message: 'Error updating booking',
            error: err.message
        });
    }
};

// DELETE: /api/bookings/:bookingId - cancel booking
const cancelBooking = async (req, res) => {
    try {
        const bookingId = req.params.bookingId;
        const userId = req.user._id;

        const result = await postgresService.query(`
            UPDATE bookings 
            SET booking_status = 'cancelled', updated_at = CURRENT_TIMESTAMP
            WHERE booking_id = $1 AND user_id = $2 AND booking_status = 'pending'
            RETURNING *
        `, [bookingId, userId], { userId, userRole: 'customer' });

        if (result.rows.length === 0) {
            return res.status(404).json({
                message: 'Booking not found or cannot be cancelled'
            });
        }

        // Audit log
        await AuditService.logBookingEvent('CANCEL_BOOKING', result.rows[0], userId, req);

        res.status(200).json({
            message: 'Booking cancelled successfully',
            booking: result.rows[0]
        });
    } catch (err) {
        console.error('Error cancelling booking:', err);
        res.status(400).json({
            message: 'Error cancelling booking',
            error: err.message
        });
    }
};

// POST: /api/bookings/:bookingId/payment - process payment
const processPayment = async (req, res) => {
    try {
        const bookingId = req.params.bookingId;
        const userId = req.user._id;

        // Verify booking exists and belongs to user
        const bookingResult = await postgresService.query(`
            SELECT * FROM bookings 
            WHERE booking_id = $1 AND user_id = $2 AND payment_status = 'unpaid'
        `, [bookingId, userId], { userId, userRole: 'customer' });

        if (bookingResult.rows.length === 0) {
            return res.status(404).json({
                message: 'Booking not found or already paid'
            });
        }

        const paymentData = {
            bookingId: bookingId,
            amount: parseFloat(req.body.amount),
            paymentMethod: req.body.paymentMethod,
            transactionId: req.body.transactionId,
            paymentStatus: 'completed',
            currency: req.body.currency || 'USD',
            processorResponse: req.body.processorResponse || {}
        };

        const payment = await postgresService.processPayment(paymentData, {
            userId: userId,
            userRole: 'system'
        });

        // Audit log
        await AuditService.logBookingEvent('PROCESS_PAYMENT', payment, userId, req);

        res.status(201).json({
            message: 'Payment processed successfully',
            payment: {
                paymentId: payment.payment_id,
                amount: payment.amount,
                status: payment.payment_status,
                transactionId: payment.transaction_id
            }
        });
    } catch (err) {
        console.error('Error processing payment:', err);
        res.status(400).json({
            message: 'Error processing payment',
            error: err.message
        });
    }
};

// GET: /api/bookings/analytics - get booking analytics (admin only)
const getBookingAnalytics = async (req, res) => {
    try {
        if (req.user.role !== 'admin') {
            return res.status(403).json({
                message: 'Access denied. Admin role required.'
            });
        }

        const startDate = req.query.startDate ? new Date(req.query.startDate) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
        const endDate = req.query.endDate ? new Date(req.query.endDate) : new Date();

        const analytics = await postgresService.getBookingAnalytics({
            startDate,
            endDate,
            userId: req.user._id
        });

        res.status(200).json({
            analytics: analytics.rows,
            period: {
                startDate,
                endDate
            }
        });
    } catch (err) {
        console.error('Error retrieving analytics:', err);
        res.status(500).json({
            message: 'Error retrieving analytics',
            error: err.message
        });
    }
};

module.exports = {
    getUserBookings,
    createBooking,
    getBooking,
    updateBooking,
    cancelBooking,
    processPayment,
    getBookingAnalytics
};
