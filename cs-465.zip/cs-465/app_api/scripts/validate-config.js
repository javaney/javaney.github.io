/**
 * Configuration Validation Script
 * Validates that all required environment variables are properly configured
 */

class ConfigValidator {
    constructor() {
        this.errors = [];
        this.warnings = [];
        this.requiredVars = [
            'JWT_SECRET',
            'POSTGRES_PASSWORD',
            'POSTGRES_HOST',
            'POSTGRES_DB',
            'POSTGRES_USER'
        ];
        
        this.optionalVars = [
            'S3_BACKUP_BUCKET',
            'AWS_ACCESS_KEY_ID',
            'AWS_SECRET_ACCESS_KEY',
            'BACKUP_ENCRYPTION_KEY',
            'ALLOWED_ORIGINS'
        ];
    }

    /**
     * Validate all configuration
     */
    async validate() {
        console.log('🔍 Validating configuration...\n');
        
        this.checkRequiredVariables();
        this.checkSecurityConfiguration();
        this.checkDatabaseConfiguration();
        this.checkOptionalConfiguration();
        
        this.printResults();
        
        if (this.errors.length > 0) {
            console.log('\n❌ Configuration validation failed!');
            process.exit(1);
        } else {
            console.log('\n✅ Configuration validation passed!');
        }
    }

    /**
     * Check required environment variables
     */
    checkRequiredVariables() {
        console.log('📋 Checking required variables...');
        
        for (const varName of this.requiredVars) {
            const value = process.env[varName];
            
            if (!value) {
                this.errors.push(`Missing required variable: ${varName}`);
            } else if (value.includes('your-') || value.includes('placeholder') || value.includes('change')) {
                this.errors.push(`Variable ${varName} contains placeholder value: ${value}`);
            } else {
                console.log(`  ✓ ${varName}: Set`);
            }
        }
    }

    /**
     * Check security configuration
     */
    checkSecurityConfiguration() {
        console.log('\n🔒 Checking security configuration...');
        
        // Check JWT secret strength
        const jwtSecret = process.env.JWT_SECRET;
        if (jwtSecret) {
            if (jwtSecret.length < 32) {
                this.errors.push(`JWT_SECRET is too short (${jwtSecret.length} chars). Minimum 32 characters required.`);
            } else {
                console.log(`  ✓ JWT_SECRET: Strong (${jwtSecret.length} characters)`);
            }
        }

        // Check password strength
        const postgresPassword = process.env.POSTGRES_PASSWORD;
        if (postgresPassword) {
            if (postgresPassword.length < 8) {
                this.warnings.push(`POSTGRES_PASSWORD is weak (${postgresPassword.length} chars). Consider using 12+ characters.`);
            } else {
                console.log(`  ✓ POSTGRES_PASSWORD: Strong (${postgresPassword.length} characters)`);
            }
        }

        // Check for default values
        const defaultValues = {
            'JWT_SECRET': ['secret', 'your-secret', 'change-me'],
            'POSTGRES_PASSWORD': ['password', 'admin', '123456'],
            'POSTGRES_USER': ['postgres', 'admin', 'root']
        };

        for (const [varName, defaults] of Object.entries(defaultValues)) {
            const value = process.env[varName];
            if (value && defaults.includes(value.toLowerCase())) {
                this.errors.push(`Variable ${varName} uses default/weak value: ${value}`);
            }
        }
    }

    /**
     * Check database configuration
     */
    checkDatabaseConfiguration() {
        console.log('\n🗄️ Checking database configuration...');
        
        const postgresHost = process.env.POSTGRES_HOST || 'localhost';
        const postgresPort = process.env.POSTGRES_PORT || '5432';
        const mongoHost = process.env.MONGO_HOST || 'localhost';
        const mongoPort = process.env.MONGO_PORT || '27017';
        
        console.log(`  ✓ PostgreSQL: ${postgresHost}:${postgresPort}`);
        console.log(`  ✓ MongoDB: ${mongoHost}:${mongoPort}`);
        
        // Check for production settings
        if (process.env.NODE_ENV === 'production') {
            if (postgresHost === 'localhost' || postgresHost === '127.0.0.1') {
                this.warnings.push('Using localhost for PostgreSQL in production is not recommended');
            }
            
            if (!process.env.POSTGRES_CA_CERT) {
                this.warnings.push('POSTGRES_CA_CERT not set for production SSL');
            }
        }
    }

    /**
     * Check optional configuration
     */
    checkOptionalConfiguration() {
        console.log('\n⚙️ Checking optional configuration...');
        
        for (const varName of this.optionalVars) {
            const value = process.env[varName];
            if (value) {
                console.log(`  ✓ ${varName}: Configured`);
            } else {
                console.log(`  - ${varName}: Not set (optional)`);
            }
        }

        // Check backup configuration
        const hasS3 = process.env.S3_BACKUP_BUCKET && process.env.AWS_ACCESS_KEY_ID;
        const hasLocalBackup = process.env.BACKUP_DIR;
        
        if (!hasS3 && !hasLocalBackup) {
            this.warnings.push('No backup configuration found. Consider setting up S3 or local backups.');
        } else if (hasS3) {
            console.log('  ✓ S3 backup configured');
        } else if (hasLocalBackup) {
            console.log('  ✓ Local backup configured');
        }
    }

    /**
     * Print validation results
     */
    printResults() {
        if (this.warnings.length > 0) {
            console.log('\n⚠️  Warnings:');
            this.warnings.forEach(warning => console.log(`  - ${warning}`));
        }

        if (this.errors.length > 0) {
            console.log('\n❌ Errors:');
            this.errors.forEach(error => console.log(`  - ${error}`));
        }
    }

    /**
     * Generate configuration recommendations
     */
    generateRecommendations() {
        console.log('\n💡 Configuration Recommendations:');
        console.log('1. Use strong, unique passwords for all database accounts');
        console.log('2. Generate a cryptographically secure JWT secret (32+ characters)');
        console.log('3. Configure proper CORS origins for your domain');
        console.log('4. Set up automated backups (S3 recommended for production)');
        console.log('5. Use environment-specific configuration files');
        console.log('6. Enable SSL/TLS for production databases');
        console.log('7. Regularly rotate secrets and passwords');
        console.log('8. Monitor database performance and security logs');
    }
}

// CLI execution
if (require.main === module) {
    require('dotenv').config();
    
    const validator = new ConfigValidator();
    
    validator.validate()
        .then(() => {
            validator.generateRecommendations();
        })
        .catch((error) => {
            console.error('Validation failed:', error);
            process.exit(1);
        });
}

module.exports = ConfigValidator;
