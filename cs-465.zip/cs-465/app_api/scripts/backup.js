/**
 * Automated Backup and Recovery System
 * Implements enterprise-grade backup procedures for PostgreSQL and MongoDB
 */

const { exec } = require('child_process');
const fs = require('fs').promises;
const path = require('path');
const AWS = require('aws-sdk');

class BackupService {
    constructor() {
        this.backupDir = process.env.BACKUP_DIR || '/var/backups/travlr';
        this.retentionDays = parseInt(process.env.BACKUP_RETENTION_DAYS) || 30;
        this.s3Bucket = process.env.S3_BACKUP_BUCKET;
        this.encryptionKey = process.env.BACKUP_ENCRYPTION_KEY;
        
        // Initialize AWS S3 if configured
        if (this.s3Bucket && process.env.AWS_ACCESS_KEY_ID) {
            this.s3 = new AWS.S3({
                region: process.env.AWS_REGION || 'us-east-1'
            });
        }
    }

    /**
     * Perform full backup of both databases
     * @returns {Promise<Object>} Backup result
     */
    async performFullBackup() {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupId = `full_backup_${timestamp}`;
        
        console.log(`Starting full backup: ${backupId}`);
        
        try {
            // Ensure backup directory exists
            await this.ensureBackupDirectory();
            
            const results = {
                backupId,
                timestamp: new Date().toISOString(),
                postgresql: null,
                mongodb: null,
                errors: []
            };

            // Backup PostgreSQL
            try {
                results.postgresql = await this.backupPostgreSQL(backupId);
                console.log('PostgreSQL backup completed successfully');
            } catch (error) {
                console.error('PostgreSQL backup failed:', error);
                results.errors.push({ database: 'postgresql', error: error.message });
            }

            // Backup MongoDB
            try {
                results.mongodb = await this.backupMongoDB(backupId);
                console.log('MongoDB backup completed successfully');
            } catch (error) {
                console.error('MongoDB backup failed:', error);
                results.errors.push({ database: 'mongodb', error: error.message });
            }

            // Upload to S3 if configured
            if (this.s3) {
                await this.uploadToS3(backupId);
            }

            // Cleanup old backups
            await this.cleanupOldBackups();

            console.log(`Full backup completed: ${backupId}`);
            return results;

        } catch (error) {
            console.error('Full backup failed:', error);
            throw error;
        }
    }

    /**
     * Backup PostgreSQL database
     * @param {string} backupId - Backup identifier
     * @returns {Promise<Object>} Backup result
     */
    async backupPostgreSQL(backupId) {
        const backupFile = path.join(this.backupDir, `postgresql_${backupId}.backup`);
        const compressedFile = `${backupFile}.gz`;
        
        const pgDumpCommand = [
            'pg_dump',
            `--host=${process.env.POSTGRES_HOST || 'localhost'}`,
            `--port=${process.env.POSTGRES_PORT || '5432'}`,
            `--username=${process.env.POSTGRES_USER || 'postgres'}`,
            `--dbname=${process.env.POSTGRES_DB || 'travlr_bookings'}`,
            '--format=custom',
            '--compress=9',
            '--verbose',
            `--file=${backupFile}`
        ].join(' ');

        return new Promise((resolve, reject) => {
            exec(pgDumpCommand, { env: { ...process.env, PGPASSWORD: process.env.POSTGRES_PASSWORD } }, async (error, stdout, stderr) => {
                if (error) {
                    reject(new Error(`PostgreSQL backup failed: ${error.message}`));
                    return;
                }

                try {
                    // Compress the backup
                    await this.compressFile(backupFile, compressedFile);
                    
                    // Verify backup integrity
                    await this.verifyPostgreSQLBackup(backupFile);
                    
                    // Get file size
                    const stats = await fs.stat(compressedFile);
                    
                    resolve({
                        file: compressedFile,
                        size: stats.size,
                        timestamp: new Date().toISOString(),
                        verified: true
                    });
                } catch (err) {
                    reject(err);
                }
            });
        });
    }

    /**
     * Backup MongoDB database
     * @param {string} backupId - Backup identifier
     * @returns {Promise<Object>} Backup result
     */
    async backupMongoDB(backupId) {
        const backupDir = path.join(this.backupDir, `mongodb_${backupId}`);
        const compressedFile = path.join(this.backupDir, `mongodb_${backupId}.tar.gz`);
        
        const mongoDumpCommand = [
            'mongodump',
            `--host=${process.env.MONGO_HOST || 'localhost:27017'}`,
            `--db=${process.env.MONGO_DB || 'travlr'}`,
            `--out=${backupDir}`
        ].join(' ');

        return new Promise((resolve, reject) => {
            exec(mongoDumpCommand, async (error, stdout, stderr) => {
                if (error) {
                    reject(new Error(`MongoDB backup failed: ${error.message}`));
                    return;
                }

                try {
                    // Compress the backup directory
                    await this.compressDirectory(backupDir, compressedFile);
                    
                    // Clean up uncompressed directory
                    await fs.rmdir(backupDir, { recursive: true });
                    
                    // Verify backup integrity
                    await this.verifyMongoDBBackup(compressedFile);
                    
                    // Get file size
                    const stats = await fs.stat(compressedFile);
                    
                    resolve({
                        file: compressedFile,
                        size: stats.size,
                        timestamp: new Date().toISOString(),
                        verified: true
                    });
                } catch (err) {
                    reject(err);
                }
            });
        });
    }

    /**
     * Verify PostgreSQL backup integrity
     * @param {string} backupFile - Path to backup file
     */
    async verifyPostgreSQLBackup(backupFile) {
        return new Promise((resolve, reject) => {
            const verifyCommand = `pg_restore --list "${backupFile}"`;
            
            exec(verifyCommand, (error, stdout, stderr) => {
                if (error) {
                    reject(new Error(`PostgreSQL backup verification failed: ${error.message}`));
                } else {
                    resolve(true);
                }
            });
        });
    }

    /**
     * Verify MongoDB backup integrity
     * @param {string} backupFile - Path to backup file
     */
    async verifyMongoDBBackup(backupFile) {
        // Extract and verify MongoDB backup
        const tempDir = path.join(this.backupDir, 'temp_verify');
        
        try {
            await this.extractFile(backupFile, tempDir);
            
            // Check if required files exist
            const requiredFiles = ['travlr/trips.bson', 'travlr/users.bson'];
            for (const file of requiredFiles) {
                const filePath = path.join(tempDir, file);
                await fs.access(filePath);
            }
            
            // Clean up temp directory
            await fs.rmdir(tempDir, { recursive: true });
            
        } catch (error) {
            throw new Error(`MongoDB backup verification failed: ${error.message}`);
        }
    }

    /**
     * Compress a file using gzip
     * @param {string} inputFile - Input file path
     * @param {string} outputFile - Output file path
     */
    async compressFile(inputFile, outputFile) {
        return new Promise((resolve, reject) => {
            const compressCommand = `gzip -c "${inputFile}" > "${outputFile}"`;
            
            exec(compressCommand, (error, stdout, stderr) => {
                if (error) {
                    reject(new Error(`File compression failed: ${error.message}`));
                } else {
                    // Remove original file
                    fs.unlink(inputFile).then(() => resolve()).catch(reject);
                }
            });
        });
    }

    /**
     * Compress a directory using tar
     * @param {string} inputDir - Input directory path
     * @param {string} outputFile - Output file path
     */
    async compressDirectory(inputDir, outputFile) {
        return new Promise((resolve, reject) => {
            const compressCommand = `tar -czf "${outputFile}" -C "${path.dirname(inputDir)}" "${path.basename(inputDir)}"`;
            
            exec(compressCommand, (error, stdout, stderr) => {
                if (error) {
                    reject(new Error(`Directory compression failed: ${error.message}`));
                } else {
                    resolve();
                }
            });
        });
    }

    /**
     * Extract a compressed file
     * @param {string} inputFile - Input file path
     * @param {string} outputDir - Output directory path
     */
    async extractFile(inputFile, outputDir) {
        return new Promise((resolve, reject) => {
            const extractCommand = `tar -xzf "${inputFile}" -C "${outputDir}"`;
            
            exec(extractCommand, (error, stdout, stderr) => {
                if (error) {
                    reject(new Error(`File extraction failed: ${error.message}`));
                } else {
                    resolve();
                }
            });
        });
    }

    /**
     * Upload backup to S3
     * @param {string} backupId - Backup identifier
     */
    async uploadToS3(backupId) {
        if (!this.s3) {
            console.log('S3 not configured, skipping upload');
            return;
        }

        try {
            const files = await fs.readdir(this.backupDir);
            const backupFiles = files.filter(file => file.includes(backupId));

            for (const file of backupFiles) {
                const filePath = path.join(this.backupDir, file);
                const fileContent = await fs.readFile(filePath);
                
                const uploadParams = {
                    Bucket: this.s3Bucket,
                    Key: `backups/${backupId}/${file}`,
                    Body: fileContent,
                    ServerSideEncryption: 'AES256',
                    StorageClass: 'STANDARD_IA'
                };

                await this.s3.upload(uploadParams).promise();
                console.log(`Uploaded ${file} to S3`);
            }
        } catch (error) {
            console.error('S3 upload failed:', error);
            throw error;
        }
    }

    /**
     * Cleanup old backups
     */
    async cleanupOldBackups() {
        try {
            const files = await fs.readdir(this.backupDir);
            const cutoffDate = new Date();
            cutoffDate.setDate(cutoffDate.getDate() - this.retentionDays);

            for (const file of files) {
                const filePath = path.join(this.backupDir, file);
                const stats = await fs.stat(filePath);
                
                if (stats.mtime < cutoffDate) {
                    await fs.unlink(filePath);
                    console.log(`Deleted old backup: ${file}`);
                }
            }
        } catch (error) {
            console.error('Backup cleanup failed:', error);
        }
    }

    /**
     * Ensure backup directory exists
     */
    async ensureBackupDirectory() {
        try {
            await fs.access(this.backupDir);
        } catch (error) {
            await fs.mkdir(this.backupDir, { recursive: true });
        }
    }

    /**
     * Restore from backup
     * @param {string} backupId - Backup identifier
     * @param {string} targetTime - Target time for point-in-time recovery
     */
    async restoreFromBackup(backupId, targetTime = null) {
        console.log(`Starting restore from backup: ${backupId}`);
        
        try {
            const results = {
                backupId,
                timestamp: new Date().toISOString(),
                postgresql: null,
                mongodb: null,
                errors: []
            };

            // Restore PostgreSQL
            try {
                results.postgresql = await this.restorePostgreSQL(backupId, targetTime);
                console.log('PostgreSQL restore completed successfully');
            } catch (error) {
                console.error('PostgreSQL restore failed:', error);
                results.errors.push({ database: 'postgresql', error: error.message });
            }

            // Restore MongoDB
            try {
                results.mongodb = await this.restoreMongoDB(backupId);
                console.log('MongoDB restore completed successfully');
            } catch (error) {
                console.error('MongoDB restore failed:', error);
                results.errors.push({ database: 'mongodb', error: error.message });
            }

            console.log(`Restore completed: ${backupId}`);
            return results;

        } catch (error) {
            console.error('Restore failed:', error);
            throw error;
        }
    }

    /**
     * Restore PostgreSQL from backup
     * @param {string} backupId - Backup identifier
     * @param {string} targetTime - Target time for point-in-time recovery
     */
    async restorePostgreSQL(backupId, targetTime = null) {
        const backupFile = path.join(this.backupDir, `postgresql_${backupId}.backup.gz`);
        
        // Decompress if needed
        let restoreFile = backupFile;
        if (backupFile.endsWith('.gz')) {
            restoreFile = backupFile.replace('.gz', '');
            await this.extractFile(backupFile, path.dirname(restoreFile));
        }

        const restoreCommand = [
            'pg_restore',
            `--host=${process.env.POSTGRES_HOST || 'localhost'}`,
            `--port=${process.env.POSTGRES_PORT || '5432'}`,
            `--username=${process.env.POSTGRES_USER || 'postgres'}`,
            `--dbname=${process.env.POSTGRES_DB || 'travlr_bookings'}`,
            '--clean',
            '--if-exists',
            '--verbose',
            restoreFile
        ].join(' ');

        return new Promise((resolve, reject) => {
            exec(restoreCommand, { env: { ...process.env, PGPASSWORD: process.env.POSTGRES_PASSWORD } }, (error, stdout, stderr) => {
                if (error) {
                    reject(new Error(`PostgreSQL restore failed: ${error.message}`));
                } else {
                    resolve({
                        success: true,
                        timestamp: new Date().toISOString()
                    });
                }
            });
        });
    }

    /**
     * Restore MongoDB from backup
     * @param {string} backupId - Backup identifier
     */
    async restoreMongoDB(backupId) {
        const backupFile = path.join(this.backupDir, `mongodb_${backupId}.tar.gz`);
        const tempDir = path.join(this.backupDir, `temp_restore_${backupId}`);
        
        try {
            // Extract backup
            await this.extractFile(backupFile, tempDir);
            
            const restoreCommand = [
                'mongorestore',
                `--host=${process.env.MONGO_HOST || 'localhost:27017'}`,
                `--db=${process.env.MONGO_DB || 'travlr'}`,
                '--drop',
                tempDir
            ].join(' ');

            return new Promise((resolve, reject) => {
                exec(restoreCommand, async (error, stdout, stderr) => {
                    // Clean up temp directory
                    try {
                        await fs.rmdir(tempDir, { recursive: true });
                    } catch (cleanupError) {
                        console.warn('Failed to clean up temp directory:', cleanupError);
                    }

                    if (error) {
                        reject(new Error(`MongoDB restore failed: ${error.message}`));
                    } else {
                        resolve({
                            success: true,
                            timestamp: new Date().toISOString()
                        });
                    }
                });
            });
        } catch (error) {
            throw new Error(`MongoDB restore failed: ${error.message}`);
        }
    }

    /**
     * Get backup status and statistics
     * @returns {Promise<Object>} Backup status
     */
    async getBackupStatus() {
        try {
            const files = await fs.readdir(this.backupDir);
            const backupFiles = files.filter(file => 
                file.includes('postgresql_') || file.includes('mongodb_')
            );

            const stats = {
                totalBackups: backupFiles.length,
                totalSize: 0,
                oldestBackup: null,
                newestBackup: null,
                files: []
            };

            for (const file of backupFiles) {
                const filePath = path.join(this.backupDir, file);
                const fileStats = await fs.stat(filePath);
                
                stats.totalSize += fileStats.size;
                stats.files.push({
                    name: file,
                    size: fileStats.size,
                    created: fileStats.mtime
                });

                if (!stats.oldestBackup || fileStats.mtime < stats.oldestBackup) {
                    stats.oldestBackup = fileStats.mtime;
                }

                if (!stats.newestBackup || fileStats.mtime > stats.newestBackup) {
                    stats.newestBackup = fileStats.mtime;
                }
            }

            return stats;
        } catch (error) {
            console.error('Failed to get backup status:', error);
            return { error: error.message };
        }
    }
}

module.exports = BackupService;
