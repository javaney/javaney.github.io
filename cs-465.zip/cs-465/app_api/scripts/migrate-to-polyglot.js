/**
 * Data Migration Script for Polyglot Persistence
 * Migrates data from MongoDB to PostgreSQL + MongoDB architecture
 */

const mongoose = require('mongoose');
const postgresService = require('../database/postgresql');
const Trip = require('../models/travlr');
const User = require('../models/user');

class DataMigrationService {
    constructor() {
        this.migrationStats = {
            users: { processed: 0, errors: 0 },
            trips: { processed: 0, errors: 0 },
            bookings: { processed: 0, errors: 0 },
            startTime: null,
            endTime: null
        };
    }

    /**
     * Initialize migration service
     */
    async initialize() {
        try {
            // Initialize PostgreSQL connection
            await postgresService.initialize();
            
            // Connect to MongoDB
            const mongoUri = process.env.MONGO_URI || 'mongodb://localhost:27017/travlr';
            await mongoose.connect(mongoUri);
            
            console.log('Migration service initialized successfully');
        } catch (error) {
            console.error('Failed to initialize migration service:', error);
            throw error;
        }
    }

    /**
     * Perform complete migration
     * @returns {Promise<Object>} Migration results
     */
    async performMigration() {
        console.log('Starting data migration to polyglot persistence...');
        this.migrationStats.startTime = new Date();

        try {
            // Step 1: Migrate users to PostgreSQL
            await this.migrateUsers();
            
            // Step 2: Migrate trips to PostgreSQL inventory
            await this.migrateTrips();
            
            // Step 3: Create sample bookings (optional - for demonstration)
            // Uncomment the line below if you want sample booking data
            // await this.createSampleBookings();
            
            // Step 4: Verify data integrity
            await this.verifyDataIntegrity();
            
            this.migrationStats.endTime = new Date();
            console.log('Data migration completed successfully');
            
            return this.migrationStats;
        } catch (error) {
            console.error('Migration failed:', error);
            throw error;
        }
    }

    /**
     * Migrate users from MongoDB to PostgreSQL
     */
    async migrateUsers() {
        console.log('Migrating users to PostgreSQL...');
        
        try {
            const users = await User.find({}).lean();
            
            for (const user of users) {
                try {
                    await postgresService.query(`
                        INSERT INTO users (
                            email, password_hash, salt, first_name, last_name,
                            role, created_at, updated_at, last_login, account_status
                        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
                        ON CONFLICT (email) DO NOTHING
                    `, [
                        user.email,
                        user.hash,
                        user.salt,
                        user.name.split(' ')[0] || 'Unknown',
                        user.name.split(' ').slice(1).join(' ') || 'User',
                        'customer',
                        user.createdAt || new Date(),
                        user.updatedAt || new Date(),
                        user.lastLogin || null,
                        'active'
                    ]);
                    
                    this.migrationStats.users.processed++;
                } catch (error) {
                    console.error(`Error migrating user ${user.email}:`, error);
                    this.migrationStats.users.errors++;
                }
            }
            
            console.log(`Users migration completed: ${this.migrationStats.users.processed} processed, ${this.migrationStats.users.errors} errors`);
        } catch (error) {
            console.error('Users migration failed:', error);
            throw error;
        }
    }

    /**
     * Migrate trips to PostgreSQL inventory
     */
    async migrateTrips() {
        console.log('Migrating trips to PostgreSQL inventory...');
        
        try {
            const trips = await Trip.find({}).lean();
            
            for (const trip of trips) {
                try {
                    // Calculate trip duration
                    const startDate = new Date(trip.start);
                    const duration = 5; // Default duration for existing trips
                    
                    await postgresService.query(`
                        INSERT INTO trip_inventory (
                            trip_code, trip_name, resort_name, price_per_person,
                            available_spots, trip_duration, start_date, end_date,
                            description, amenities, images, created_at, updated_at
                        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
                        ON CONFLICT (trip_code) DO UPDATE SET
                            trip_name = EXCLUDED.trip_name,
                            resort_name = EXCLUDED.resort_name,
                            price_per_person = EXCLUDED.price_per_person,
                            description = EXCLUDED.description,
                            updated_at = EXCLUDED.updated_at
                    `, [
                        trip.code,
                        trip.name,
                        trip.resort,
                        trip.perPerson,
                        100, // Default available spots
                        duration,
                        startDate,
                        new Date(startDate.getTime() + duration * 24 * 60 * 60 * 1000),
                        trip.description,
                        JSON.stringify({ length: trip.length }),
                        JSON.stringify({ image: trip.image }),
                        new Date(),
                        new Date()
                    ]);
                    
                    this.migrationStats.trips.processed++;
                } catch (error) {
                    console.error(`Error migrating trip ${trip.code}:`, error);
                    this.migrationStats.trips.errors++;
                }
            }
            
            console.log(`Trips migration completed: ${this.migrationStats.trips.processed} processed, ${this.migrationStats.trips.errors} errors`);
        } catch (error) {
            console.error('Trips migration failed:', error);
            throw error;
        }
    }

    /**
     * Create sample bookings for demonstration
     */
    async createSampleBookings() {
        console.log('Creating sample bookings...');
        
        try {
            // Get a sample user
            const userResult = await postgresService.query('SELECT user_id FROM users LIMIT 1');
            if (userResult.rows.length === 0) {
                console.log('No users found, skipping sample bookings');
                return;
            }
            
            const userId = userResult.rows[0].user_id;
            
            // Get available trips
            const tripsResult = await postgresService.query('SELECT trip_code, price_per_person FROM trip_inventory LIMIT 3');
            
            for (const trip of tripsResult.rows) {
                try {
                    const bookingData = {
                        userId: userId,
                        tripCode: trip.trip_code,
                        travelDate: new Date(Date.now() + Math.random() * 30 * 24 * 60 * 60 * 1000),
                        returnDate: new Date(Date.now() + Math.random() * 30 * 24 * 60 * 60 * 1000 + 5 * 24 * 60 * 60 * 1000),
                        numTravelers: Math.floor(Math.random() * 4) + 1,
                        totalAmount: trip.price_per_person * (Math.floor(Math.random() * 4) + 1),
                        specialRequests: 'Sample booking for demonstration',
                        emergencyContact: {
                            name: 'Emergency Contact',
                            phone: '+1-555-0123',
                            relationship: 'Family'
                        }
                    };
                    
                    const booking = await postgresService.createBooking(bookingData, {
                        userId: userId,
                        userRole: 'customer'
                    });
                    
                    // Create a sample payment
                    const paymentData = {
                        bookingId: booking.booking_id,
                        amount: bookingData.totalAmount,
                        paymentMethod: 'credit_card',
                        transactionId: `TXN_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                        paymentStatus: 'completed',
                        currency: 'USD',
                        processorResponse: {
                            status: 'approved',
                            transaction_id: `TXN_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
                        }
                    };
                    
                    await postgresService.processPayment(paymentData, {
                        userId: userId,
                        userRole: 'system'
                    });
                    
                    this.migrationStats.bookings.processed++;
                } catch (error) {
                    console.error(`Error creating sample booking:`, error);
                    this.migrationStats.bookings.errors++;
                }
            }
            
            console.log(`Sample bookings created: ${this.migrationStats.bookings.processed} processed, ${this.migrationStats.bookings.errors} errors`);
        } catch (error) {
            console.error('Sample bookings creation failed:', error);
            throw error;
        }
    }

    /**
     * Verify data integrity after migration
     */
    async verifyDataIntegrity() {
        console.log('Verifying data integrity...');
        
        try {
            // Check user counts
            const userCount = await postgresService.query('SELECT COUNT(*) as count FROM users');
            console.log(`PostgreSQL users: ${userCount.rows[0].count}`);
            
            // Check trip counts
            const tripCount = await postgresService.query('SELECT COUNT(*) as count FROM trip_inventory');
            console.log(`PostgreSQL trips: ${tripCount.rows[0].count}`);
            
            // Check booking counts
            const bookingCount = await postgresService.query('SELECT COUNT(*) as count FROM bookings');
            console.log(`PostgreSQL bookings: ${bookingCount.rows[0].count}`);
            
            // Check payment counts
            const paymentCount = await postgresService.query('SELECT COUNT(*) as count FROM payments');
            console.log(`PostgreSQL payments: ${paymentCount.rows[0].count}`);
            
            // Verify MongoDB still has trips
            const mongoTripCount = await Trip.countDocuments();
            console.log(`MongoDB trips: ${mongoTripCount}`);
            
            console.log('Data integrity verification completed');
        } catch (error) {
            console.error('Data integrity verification failed:', error);
            throw error;
        }
    }

    /**
     * Create database indexes for performance
     */
    async createIndexes() {
        console.log('Creating performance indexes...');
        
        try {
            // PostgreSQL indexes are created in the schema file
            // MongoDB indexes
            await Trip.collection.createIndex({ name: 'text', description: 'text', resort: 'text' });
            await Trip.collection.createIndex({ code: 1 });
            await Trip.collection.createIndex({ perPerson: 1 });
            await Trip.collection.createIndex({ start: 1 });
            
            console.log('Indexes created successfully');
        } catch (error) {
            console.error('Index creation failed:', error);
            throw error;
        }
    }

    /**
     * Get migration statistics
     * @returns {Object} Migration statistics
     */
    getStats() {
        const duration = this.migrationStats.endTime ? 
            this.migrationStats.endTime - this.migrationStats.startTime : 
            Date.now() - this.migrationStats.startTime;
            
        return {
            ...this.migrationStats,
            duration: duration,
            durationFormatted: this.formatDuration(duration)
        };
    }

    /**
     * Format duration in human-readable format
     * @param {number} duration - Duration in milliseconds
     * @returns {string} Formatted duration
     */
    formatDuration(duration) {
        const seconds = Math.floor(duration / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        
        if (hours > 0) {
            return `${hours}h ${minutes % 60}m ${seconds % 60}s`;
        } else if (minutes > 0) {
            return `${minutes}m ${seconds % 60}s`;
        } else {
            return `${seconds}s`;
        }
    }

    /**
     * Close connections
     */
    async close() {
        try {
            await postgresService.close();
            await mongoose.connection.close();
            console.log('Migration service connections closed');
        } catch (error) {
            console.error('Error closing connections:', error);
        }
    }
}

// CLI execution
if (require.main === module) {
    const migrationService = new DataMigrationService();
    
    migrationService.initialize()
        .then(() => migrationService.performMigration())
        .then((results) => {
            console.log('Migration Results:', results);
            return migrationService.close();
        })
        .catch((error) => {
            console.error('Migration failed:', error);
            process.exit(1);
        });
}

module.exports = DataMigrationService;
