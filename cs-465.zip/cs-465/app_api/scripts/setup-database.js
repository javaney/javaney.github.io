/**
 * Database Setup Script for Polyglot Persistence
 * Sets up PostgreSQL schema and initializes the database
 */

const fs = require('fs').promises');
const path = require('path');
const { exec } = require('child_process');
const postgresService = require('../database/postgresql');

class DatabaseSetup {
    constructor() {
        this.setupLog = [];
    }

    /**
     * Initialize database setup
     */
    async initialize() {
        console.log('🚀 Starting database setup for polyglot persistence...');
        
        try {
            // Initialize PostgreSQL connection
            await postgresService.initialize();
            this.log('PostgreSQL connection initialized');
            
            // Run schema setup
            await this.setupPostgreSQLSchema();
            
            // Run security setup
            await this.setupSecurityPolicies();
            
            // Verify setup
            await this.verifySetup();
            
            // Create sample data (optional)
            if (process.env.CREATE_SAMPLE_DATA === 'true') {
                await this.createSampleData();
            }
            
            console.log('✅ Database setup completed successfully!');
            console.log('\n📊 Setup Summary:');
            this.setupLog.forEach(log => console.log(`   ${log}`));
            
        } catch (error) {
            console.error('❌ Database setup failed:', error);
            throw error;
        } finally {
            await postgresService.close();
        }
    }

    /**
     * Setup PostgreSQL schema
     */
    async setupPostgreSQLSchema() {
        console.log('📋 Setting up PostgreSQL schema...');
        
        try {
            const schemaPath = path.join(__dirname, '..', 'database', 'postgresql-schema.sql');
            const schemaSQL = await fs.readFile(schemaPath, 'utf8');
            
            // Split schema into individual statements
            const statements = schemaSQL
                .split(';')
                .map(stmt => stmt.trim())
                .filter(stmt => stmt.length > 0 && !stmt.startsWith('--'));
            
            for (const statement of statements) {
                if (statement.trim()) {
                    try {
                        await postgresService.query(statement);
                    } catch (error) {
                        // Some statements might fail if objects already exist
                        if (!error.message.includes('already exists')) {
                            console.warn(`Warning: ${error.message}`);
                        }
                    }
                }
            }
            
            this.log('PostgreSQL schema created successfully');
        } catch (error) {
            console.error('Error setting up PostgreSQL schema:', error);
            throw error;
        }
    }

    /**
     * Setup security policies
     */
    async setupSecurityPolicies() {
        console.log('🔒 Setting up security policies...');
        
        try {
            const securityPath = path.join(__dirname, '..', 'database', 'security-policies.sql');
            const securitySQL = await fs.readFile(securityPath, 'utf8');
            
            // Split security policies into individual statements
            const statements = securitySQL
                .split(';')
                .map(stmt => stmt.trim())
                .filter(stmt => stmt.length > 0 && !stmt.startsWith('--'));
            
            for (const statement of statements) {
                if (statement.trim()) {
                    try {
                        await postgresService.query(statement);
                    } catch (error) {
                        // Some statements might fail if objects already exist
                        if (!error.message.includes('already exists')) {
                            console.warn(`Warning: ${error.message}`);
                        }
                    }
                }
            }
            
            this.log('Security policies configured successfully');
        } catch (error) {
            console.error('Error setting up security policies:', error);
            throw error;
        }
    }

    /**
     * Verify database setup
     */
    async verifySetup() {
        console.log('🔍 Verifying database setup...');
        
        try {
            // Check if tables exist
            const tablesResult = await postgresService.query(`
                SELECT table_name 
                FROM information_schema.tables 
                WHERE table_schema = 'public' 
                ORDER BY table_name
            `);
            
            const expectedTables = ['users', 'bookings', 'payments', 'trip_inventory', 'audit_log', 'user_sessions'];
            const existingTables = tablesResult.rows.map(row => row.table_name);
            
            for (const table of expectedTables) {
                if (existingTables.includes(table)) {
                    this.log(`✓ Table '${table}' exists`);
                } else {
                    throw new Error(`Table '${table}' is missing`);
                }
            }
            
            // Check if indexes exist
            const indexesResult = await postgresService.query(`
                SELECT indexname 
                FROM pg_indexes 
                WHERE schemaname = 'public'
                ORDER BY indexname
            `);
            
            this.log(`✓ ${indexesResult.rows.length} indexes created`);
            
            // Check if functions exist
            const functionsResult = await postgresService.query(`
                SELECT routine_name 
                FROM information_schema.routines 
                WHERE routine_schema = 'public' 
                AND routine_type = 'FUNCTION'
            `);
            
            this.log(`✓ ${functionsResult.rows.length} functions created`);
            
            // Check if triggers exist
            const triggersResult = await postgresService.query(`
                SELECT trigger_name 
                FROM information_schema.triggers 
                WHERE trigger_schema = 'public'
            `);
            
            this.log(`✓ ${triggersResult.rows.length} triggers created`);
            
            // Check if views exist
            const viewsResult = await postgresService.query(`
                SELECT table_name 
                FROM information_schema.views 
                WHERE table_schema = 'public'
            `);
            
            this.log(`✓ ${viewsResult.rows.length} views created`);
            
            this.log('Database verification completed successfully');
        } catch (error) {
            console.error('Error verifying database setup:', error);
            throw error;
        }
    }

    /**
     * Create sample data for testing
     */
    async createSampleData() {
        console.log('📝 Creating sample data...');
        
        try {
            // Create sample users with proper password hashing
            const crypto = require('crypto');
            
            // Generate proper password hashes
            const adminSalt = crypto.randomBytes(32).toString('hex');
            const customerSalt = crypto.randomBytes(32).toString('hex');
            const adminHash = crypto.pbkdf2Sync('admin123', adminSalt, 10000, 64, 'sha512').toString('hex');
            const customerHash = crypto.pbkdf2Sync('customer123', customerSalt, 10000, 64, 'sha512').toString('hex');
            
            await postgresService.query(`
                INSERT INTO users (email, password_hash, salt, first_name, last_name, role)
                VALUES 
                    ('admin@travlr.com', $1, $2, 'Admin', 'User', 'admin'),
                    ('customer@travlr.com', $3, $4, 'John', 'Doe', 'customer')
                ON CONFLICT (email) DO NOTHING
            `, [adminHash, adminSalt, customerHash, customerSalt]);
            
            this.log('Sample users created');
            
            // Create sample trip inventory
            await postgresService.query(`
                INSERT INTO trip_inventory (trip_code, trip_name, resort_name, price_per_person, available_spots, trip_duration, start_date, end_date, description)
                VALUES 
                    ('GALR', 'Gale Reef', 'Emerald Bay, 3-star', 799.00, 50, 5, '2025-06-01', '2025-06-06', 'Gale Reef - Sed et augue lorem. In sit amet placerat arcu.'),
                    ('DAWR', 'Dawson Reef', 'Blue Lagoon, 4-star', 1199.00, 30, 5, '2025-06-15', '2025-06-20', 'Dawson Reef - Sed consequat libero ut turpis venenatis.'),
                    ('CR12', 'Claire Reef', 'Coral Sands, 5-star', 1999.00, 20, 5, '2025-07-01', '2025-07-06', 'Claire Reef - Donec sed felis risus. Nulla facilisi.')
                ON CONFLICT (trip_code) DO UPDATE SET
                    trip_name = EXCLUDED.trip_name,
                    price_per_person = EXCLUDED.price_per_person
            `);
            
            this.log('Sample trip inventory created');
            
            this.log('Sample data creation completed');
        } catch (error) {
            console.error('Error creating sample data:', error);
            throw error;
        }
    }

    /**
     * Log setup progress
     * @param {string} message - Log message
     */
    log(message) {
        const timestamp = new Date().toISOString();
        this.setupLog.push(`[${timestamp}] ${message}`);
    }

    /**
     * Get setup summary
     * @returns {Object} Setup summary
     */
    getSummary() {
        return {
            timestamp: new Date().toISOString(),
            logs: this.setupLog,
            totalSteps: this.setupLog.length
        };
    }
}

// CLI execution
if (require.main === module) {
    const setup = new DatabaseSetup();
    
    setup.initialize()
        .then(() => {
            console.log('\n🎉 Database setup completed successfully!');
            console.log('\nNext steps:');
            console.log('1. Run the migration script: node app_api/scripts/migrate-to-polyglot.js');
            console.log('2. Start the application: npm start');
            console.log('3. Test the API endpoints');
        })
        .catch((error) => {
            console.error('Setup failed:', error);
            process.exit(1);
        });
}

module.exports = DatabaseSetup;
