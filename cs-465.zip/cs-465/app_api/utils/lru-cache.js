/**
 * LRU Cache Implementation with O(1) access time
 * Uses HashMap for O(1) key lookup and doubly-linked list for O(1) insertion/deletion
 * Supports configurable capacity, hit/miss tracking, and automatic eviction
 */

class LRUCache {
    constructor(capacity = 1000) {
        this.capacity = capacity;
        this.cache = new Map(); // HashMap for O(1) key lookup
        this.hits = 0;
        this.misses = 0;
        this.totalOperations = 0;
    }

    /**
     * Get a value from the cache
     * @param {string} key - The cache key
     * @returns {*} The cached value or null if not found
     */
    get(key) {
        this.totalOperations++;
        
        if (!this.cache.has(key)) {
            this.misses++;
            return null;
        }
        
        this.hits++;
        const value = this.cache.get(key);
        
        // Move to end (most recently used) - Map maintains insertion order
        this.cache.delete(key);
        this.cache.set(key, value);
        
        return value;
    }

    /**
     * Put a value into the cache
     * @param {string} key - The cache key
     * @param {*} value - The value to cache
     */
    put(key, value) {
        this.totalOperations++;
        
        if (this.cache.has(key)) {
            // Update existing key - move to end
            this.cache.delete(key);
        } else if (this.cache.size >= this.capacity) {
            // Remove least recently used (first item in Map)
            const firstKey = this.cache.keys().next().value;
            this.cache.delete(firstKey);
        }
        
        this.cache.set(key, value);
    }

    /**
     * Check if a key exists in the cache
     * @param {string} key - The cache key
     * @returns {boolean} True if key exists
     */
    has(key) {
        return this.cache.has(key);
    }

    /**
     * Delete a key from the cache
     * @param {string} key - The cache key
     * @returns {boolean} True if key was deleted
     */
    delete(key) {
        return this.cache.delete(key);
    }

    /**
     * Clear all entries from the cache
     */
    clear() {
        this.cache.clear();
        this.hits = 0;
        this.misses = 0;
        this.totalOperations = 0;
    }

    /**
     * Get the current hit rate percentage
     * @returns {number} Hit rate as a percentage (0-100)
     */
    getHitRate() {
        const total = this.hits + this.misses;
        return total > 0 ? (this.hits / total) * 100 : 0;
    }

    /**
     * Get cache statistics
     * @returns {Object} Cache statistics
     */
    getStats() {
        return {
            size: this.cache.size,
            capacity: this.capacity,
            hits: this.hits,
            misses: this.misses,
            totalOperations: this.totalOperations,
            hitRate: this.getHitRate(),
            memoryUsage: this._estimateMemoryUsage()
        };
    }

    /**
     * Get all keys in the cache (in LRU order)
     * @returns {Array} Array of cache keys
     */
    keys() {
        return Array.from(this.cache.keys());
    }

    /**
     * Get all values in the cache (in LRU order)
     * @returns {Array} Array of cache values
     */
    values() {
        return Array.from(this.cache.values());
    }

    /**
     * Get all entries in the cache (in LRU order)
     * @returns {Array} Array of [key, value] pairs
     */
    entries() {
        return Array.from(this.cache.entries());
    }

    /**
     * Resize the cache capacity
     * @param {number} newCapacity - New capacity size
     */
    resize(newCapacity) {
        if (newCapacity < 0) {
            throw new Error('Capacity must be non-negative');
        }
        
        this.capacity = newCapacity;
        
        // If new capacity is smaller, remove excess items
        while (this.cache.size > this.capacity) {
            const firstKey = this.cache.keys().next().value;
            this.cache.delete(firstKey);
        }
    }

    /**
     * Estimate memory usage of the cache
     * @returns {number} Estimated memory usage in bytes
     */
    _estimateMemoryUsage() {
        let totalSize = 0;
        
        for (const [key, value] of this.cache) {
            // Rough estimation
            totalSize += this._getSize(key);
            totalSize += this._getSize(value);
        }
        
        return totalSize;
    }

    /**
     * Get approximate size of an object
     * @param {*} obj - Object to measure
     * @returns {number} Approximate size in bytes
     */
    _getSize(obj) {
        if (typeof obj === 'string') {
            return obj.length * 2; // UTF-16
        } else if (typeof obj === 'number') {
            return 8;
        } else if (typeof obj === 'boolean') {
            return 4;
        } else if (obj === null || obj === undefined) {
            return 0;
        } else if (Array.isArray(obj)) {
            return obj.reduce((size, item) => size + this._getSize(item), 0);
        } else if (typeof obj === 'object') {
            return Object.keys(obj).reduce((size, key) => {
                return size + this._getSize(key) + this._getSize(obj[key]);
            }, 0);
        }
        
        return 100; // Default estimate for complex objects
    }

    /**
     * Create a snapshot of the cache for debugging
     * @returns {Object} Cache snapshot
     */
    snapshot() {
        return {
            entries: this.entries(),
            stats: this.getStats(),
            timestamp: new Date().toISOString()
        };
    }
}

module.exports = LRUCache;
