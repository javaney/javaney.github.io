/**
 * Trie Data Structure for Autocomplete Functionality
 * Implements O(m) search complexity where m is the length of the search prefix
 * Supports efficient prefix-based search for trip names and resort names
 */

class TrieNode {
    constructor() {
        this.children = new Map();
        this.tripIds = [];
        this.isEndOfWord = false;
    }
}

class SearchTrie {
    constructor() {
        this.root = new TrieNode();
        this.totalWords = 0;
    }

    /**
     * Insert a word into the trie with associated trip ID
     * @param {string} word - The word to insert
     * @param {string} tripId - The trip ID associated with this word
     */
    insert(word, tripId) {
        if (!word || !tripId) return;
        
        let node = this.root;
        const normalizedWord = word.toLowerCase().trim();
        
        for (const char of normalizedWord) {
            if (!node.children.has(char)) {
                node.children.set(char, new TrieNode());
            }
            node = node.children.get(char);
        }
        
        node.isEndOfWord = true;
        if (!node.tripIds.includes(tripId)) {
            node.tripIds.push(tripId);
        }
        this.totalWords++;
    }

    /**
     * Search for words with the given prefix
     * @param {string} prefix - The search prefix
     * @param {number} maxResults - Maximum number of results to return
     * @returns {Array} Array of trip IDs matching the prefix
     */
    search(prefix) {
        if (!prefix || prefix.length < 2) return [];
        
        let node = this.root;
        const normalizedPrefix = prefix.toLowerCase().trim();
        
        // Navigate to the prefix node
        for (const char of normalizedPrefix) {
            if (!node.children.has(char)) {
                return [];
            }
            node = node.children.get(char);
        }
        
        return this.collectSuggestions(node, normalizedPrefix);
    }

    /**
     * Collect all suggestions from a given node
     * @param {TrieNode} node - Starting node
     * @param {string} prefix - Current prefix
     * @param {number} maxResults - Maximum results to return
     * @returns {Array} Array of trip IDs
     */
    collectSuggestions(node, prefix, maxResults = 10) {
        const suggestions = [];
        
        if (node.isEndOfWord) {
            suggestions.push(...node.tripIds);
        }
        
        if (suggestions.length >= maxResults) {
            return suggestions.slice(0, maxResults);
        }
        
        // Recursively collect from children
        for (const [char, childNode] of node.children) {
            const childSuggestions = this.collectSuggestions(
                childNode, 
                prefix + char, 
                maxResults - suggestions.length
            );
            suggestions.push(...childSuggestions);
            
            if (suggestions.length >= maxResults) break;
        }
        
        return suggestions.slice(0, maxResults);
    }

    /**
     * Get all words in the trie (for debugging)
     * @returns {Array} All words in the trie
     */
    getAllWords() {
        const words = [];
        this._collectAllWords(this.root, '', words);
        return words;
    }

    /**
     * Private method to collect all words recursively
     * @param {TrieNode} node - Current node
     * @param {string} currentWord - Current word being built
     * @param {Array} words - Array to store words
     */
    _collectAllWords(node, currentWord, words) {
        if (node.isEndOfWord) {
            words.push({
                word: currentWord,
                tripIds: node.tripIds
            });
        }
        
        for (const [char, childNode] of node.children) {
            this._collectAllWords(childNode, currentWord + char, words);
        }
    }

    /**
     * Get statistics about the trie
     * @returns {Object} Trie statistics
     */
    getStats() {
        return {
            totalWords: this.totalWords,
            totalNodes: this._countNodes(this.root),
            memoryUsage: this._estimateMemoryUsage()
        };
    }

    /**
     * Count total nodes in the trie
     * @param {TrieNode} node - Starting node
     * @returns {number} Total node count
     */
    _countNodes(node) {
        let count = 1;
        for (const childNode of node.children.values()) {
            count += this._countNodes(childNode);
        }
        return count;
    }

    /**
     * Estimate memory usage of the trie
     * @returns {number} Estimated memory usage in bytes
     */
    _estimateMemoryUsage() {
        const avgCharSize = 2; // UTF-16
        const avgTripIdSize = 24; // MongoDB ObjectId size
        const nodeOverhead = 100; // Map and array overhead
        
        return this._countNodes(this.root) * (avgCharSize + nodeOverhead) + 
               this.totalWords * avgTripIdSize;
    }

    /**
     * Clear all data from the trie
     */
    clear() {
        this.root = new TrieNode();
        this.totalWords = 0;
    }
}

module.exports = { SearchTrie, TrieNode };
