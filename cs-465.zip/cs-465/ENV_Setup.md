# Environment Configuration Guide

## Required Environment Variables

The application requires several environment variables to be configured. Create a `.env` file in the root directory with the following variables:

### 🔐 **Critical Security Variables (MUST BE CHANGED)**

```bash
# JWT Secret - Generate a strong random string
JWT_SECRET=your-super-secret-jwt-key-minimum-32-characters-long

# Database Passwords - Use strong passwords
POSTGRES_PASSWORD=your-strong-postgres-password-here
DB_PASSWORD=your-strong-mongodb-password-here

# Backup Encryption Key - Generate a 32-character random string
BACKUP_ENCRYPTION_KEY=your-32-character-encryption-key-here
```

### 🗄️ **Database Configuration**

```bash
# PostgreSQL Configuration
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=travlr_bookings
POSTGRES_USER=travlr_app
POSTGRES_PASSWORD=your-strong-postgres-password-here
POSTGRES_MAX_CONNECTIONS=20
POSTGRES_MIN_CONNECTIONS=5

# MongoDB Configuration
MONGO_URI=mongodb://localhost:27017/travlr
MONGO_HOST=localhost
MONGO_PORT=27017
MONGO_DB=travlr
DB_HOST=127.0.0.1
DB_PORT=27017
DB_NAME=travlr
```

### 🔒 **Security Configuration**

```bash
# CORS Origins (comma-separated)
ALLOWED_ORIGINS=http://localhost:4200,http://localhost:3002

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
AUTH_RATE_LIMIT_MAX_REQUESTS=5
TRIP_RATE_LIMIT_MAX_REQUESTS=10
```

### ☁️ **Backup Configuration (Optional)**

```bash
# AWS S3 Backup (optional)
S3_BACKUP_BUCKET=your-backup-bucket-name
AWS_ACCESS_KEY_ID=your-aws-access-key
AWS_SECRET_ACCESS_KEY=your-aws-secret-key
AWS_REGION=us-east-1

# Local Backup
BACKUP_DIR=/var/backups/travlr
BACKUP_RETENTION_DAYS=30
```

## 🔧 **Setup Instructions**

### 1. **Generate Secure Keys**

```bash
# Generate JWT Secret (32+ characters)
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

# Generate Backup Encryption Key (32 characters)
node -e "console.log(require('crypto').randomBytes(16).toString('hex'))"
```

### 2. **Database Setup**

```bash
# Install PostgreSQL and MongoDB
# Create databases
createdb travlr_bookings
mongo --eval "db = db.getSiblingDB('travlr')"

# Run database setup
node app_api/scripts/setup-database.js
```

### 3. **Sample Data**

The setup script creates sample users with these credentials:
- **Admin**: `admin@travlr.com` / `admin123`
- **Customer**: `customer@travlr.com` / `customer123`

**⚠️ IMPORTANT**: Change these passwords immediately in production!

### 4. **Production Security Checklist**

- [ ] Change all default passwords
- [ ] Generate strong JWT secret (32+ characters)
- [ ] Use strong database passwords (12+ characters)
- [ ] Configure proper CORS origins
- [ ] Set up SSL certificates for production
- [ ] Configure backup encryption keys
- [ ] Review and adjust rate limiting settings
- [ ] Enable database encryption at rest
- [ ] Set up monitoring and alerting

## 🚨 **Security Warnings**

1. **Never commit `.env` files to version control**
2. **Use different secrets for each environment**
3. **Rotate secrets regularly in production**
4. **Use environment-specific database credentials**
5. **Enable database encryption in production**
6. **Configure proper firewall rules**
7. **Use HTTPS in production**

## 📝 **Environment File Template**

Create a `.env` file with this template:

```bash
# Copy this to .env and fill in your values
NODE_ENV=development
PORT=3002

# Security (CHANGE THESE!)
JWT_SECRET=your-jwt-secret-here
POSTGRES_PASSWORD=your-postgres-password
BACKUP_ENCRYPTION_KEY=your-encryption-key

# Database
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=travlr_bookings
POSTGRES_USER=travlr_app

MONGO_URI=mongodb://localhost:27017/travlr
DB_HOST=127.0.0.1
DB_PORT=27017
DB_NAME=travlr

# CORS
ALLOWED_ORIGINS=http://localhost:4200,http://localhost:3002

# Optional: AWS Backup
S3_BACKUP_BUCKET=your-backup-bucket
AWS_ACCESS_KEY_ID=your-aws-key
AWS_SECRET_ACCESS_KEY=your-aws-secret
AWS_REGION=us-east-1
```
