// Direct database access using API model
const Trip = require('../../app_api/models/travlr');

// GET travel view
const travel = async (req, res) => {
    try {
        // Direct database query instead of HTTP call
        const trips = await Trip.find({});

        if (!trips || trips.length === 0) {
            console.log('No trips found in database');
            return res.render('travel', {
                title: 'Travlr Getaways',
                pageTitle: 'Travel',
                currentPage: 'travel',
                trips: [],
                message: 'No trips available at this time'
            });
        }

        res.render('travel', {
            title: 'Travlr Getaways',
            pageTitle: 'Travel',
            currentPage: 'travel',
            trips: trips
        });
    } catch (err) {
        console.log('Database Error:', err.message);
        res.status(500).send('Error retrieving trips: ' + err.message);
    }
};

module.exports = {
    travel
};
