export const trips = [
  {
    "code": "GALR",
    "name": "Gale Reef",
    "length": "4 nights / 5 days",
    "start": "2021-06-01",
    "resort": "Emerald Bay, 3-star",
    "perPerson": "799.00",
    "image": "reef1.jpg",
    "description": "Gale Reef - Sed et augue lorem. In sit amet placerat arcu. Mauris volutpat ipsum ac justo mollis vel vestibulum orci gravida. Vestibulum sit amet porttitor odio. Nulla facilisi. Fusce at pretium felis."
  },
  {
    "code": "DAWR",
    "name": "Dawson's Reef",
    "length": "4 nights / 5 days", 
    "start": "2021-06-01",
    "resort": "Blue Lagoon, 4-star",
    "perPerson": "1199.00",
    "image": "reef2.jpg",
    "description": "Dawson's Reef - Sed consequat libero ut turpis venenatis ut aliquam risus suscipit. Etiam convallis mi vel risus pretium sodales. Etiam nunc lorem ullamcorper vitae laoreet."
  },
  {
    "code": "CR12",
    "name": "Claire's Reef",
    "length": "4 nights / 5 days",
    "start": "2021-06-01", 
    "resort": "Coral Sands, 5-star",
    "perPerson": "1999.00",
    "image": "reef3.jpg",
    "description": "Claire's Reef - Donec sed felis risus. Nulla facilisi. Integer magna leo, posuere et dignissim vitae, porttitor at odio. Pellentesque a ipsum vel lacus vehicula sodales sed non lacus."
  }
];
