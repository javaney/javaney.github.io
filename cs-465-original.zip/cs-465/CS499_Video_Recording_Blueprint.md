# CS 499 Code Review Video Recording Blueprint
**Complete Conversational Template - Just Read and Follow**

---

## 🎬 INTRODUCTION (2 minutes)
**SCREEN: Show desktop with project folder open**

**SAY EXACTLY:**
"Hello, I'm Javaney Thomas, and today I'll be conducting a code review of my Travlr Getaways application - a full-stack travel booking platform built with the MEAN stack. This review will cover three categories: Software Engineering and Design, Algorithms and Data Structures, and Databases. I'll analyze the current functionality, identify areas for improvement, and explain my planned enhancements that align with the CS 499 course outcomes."

**ACTION: Open file explorer showing cs-465 folder structure**

---

## 📁 CATEGORY ONE: SOFTWARE DESIGN AND ENGINEERING (8-9 minutes)

### Part 1: Existing Functionality Description (2-3 minutes)

**SCREEN: Open VS Code with project structure visible**

**SAY:**
"Let me start by describing the existing functionality of the Travlr application. The application consists of two main interfaces built with the MEAN stack."

**ACTION: Navigate to and open `app.js`**

**SAY:**
"First, we have the main Express server configuration in app.js. This handles both the customer-facing website and the API backend. The customer site uses Handlebars templating for server-side rendering, allowing users to browse travel packages."

**ACTION: Scroll to lines 10-11 in app.js**

**SAY:**
"Here you can see we're establishing database connections for both the server and API components."

**ACTION: Open `app_admin/src/app` folder**

**SAY:**
"Second, we have an administrative Single Page Application built with Angular 20 using standalone components. This provides secure CRUD operations for managing trips and users."

**ACTION: Open `app_api/routes/trips.js`**

**SAY:**
"The application implements RESTful API endpoints with JWT-based authentication. Here you can see our trip management routes with authentication middleware protecting the POST, PUT, and DELETE operations."

**ACTION: Open `app_api/models/user.js`**

**SAY:**
"Security is handled through Passport.js with PBKDF2 password hashing and JWT tokens for session management."

### Part 2: Code Analysis (3-4 minutes)

**SCREEN: Keep `app.js` open, highlight lines 10-11**

**SAY:**
"Now let me analyze the current code using relevant code review criteria. I've identified several structure and design issues."

**SAY:**
"First, looking at app.js lines 10-11, I notice we're establishing dual database connections - both app_server/models/db and app_api/models/db. This creates unnecessary redundancy and potential connection conflicts."

**ACTION: Open `app_api/routes/index.js`, scroll to lines 7-12**

**SAY:**
"Second, examining our CORS configuration in routes/index.js lines 7-12, I see we're using wildcard origins with the asterisk symbol. This is a significant security risk for production environments as it allows any domain to access our API."

**ACTION: Open `app_api/controllers/trips.js`, scroll to line 63**

**SAY:**
"Third, in our trips controller at line 63, there's no input sanitization - we're passing raw req.body directly to MongoDB operations. This exposes us to NoSQL injection attacks."

**ACTION: Open `app_admin/src/app/utils/jwt.interceptor.ts`**

**SAY:**
"Fourth, the JWT interceptor only checks for login and register URLs but doesn't validate token expiration before sending requests, which could lead to unnecessary failed requests."

**ACTION: Open `app_admin/src/app/services/trip-data.ts`**

**SAY:**
"Finally, I notice the trip data service mixes authentication and trip management concerns in a single service, violating the single responsibility principle."

### Part 3: Planned Enhancements (2-3 minutes)

**SCREEN: Keep current file open**

**SAY:**
"My enhancement plan addresses these issues through three main improvements."

**SAY:**
"First, I'll implement a microservices architecture. I'll refactor the monolithic structure into separate services, eliminating the dual database connection issue and implementing proper service boundaries. This demonstrates Course Outcome 3 - designing computing solutions with proper architectural principles."

**SAY:**
"Second, I'll implement comprehensive security improvements including input validation middleware, rate limiting, and environment-specific CORS policies. This aligns with Course Outcome 5 - developing a security mindset."

**SAY:**
"Third, I'll focus on code modularization by separating authentication services from business logic and eliminating code duplication. This supports Course Outcome 4 - using innovative techniques and tools."

---

## 🔢 CATEGORY TWO: ALGORITHMS AND DATA STRUCTURES (8-9 minutes)

### Part 1: Existing Functionality Description (2-3 minutes)

**SCREEN: Open `app_api/controllers/trips.js`**

**SAY:**
"Moving to algorithms and data structures, let me describe the current functionality. The application uses basic CRUD operations for trip data management."

**ACTION: Scroll to `tripsList` function around line 4**

**SAY:**
"The tripsList function performs simple Trip.find empty object queries without any optimization or caching."

**ACTION: Open `app_api/models/travlr.js`**

**SAY:**
"Our trip schema has basic indexing on code and name fields, but the data structures are primarily simple JavaScript objects and MongoDB documents."

**ACTION: Open `app_admin/src/app/trip-listing/trip-listing.ts`**

**SAY:**
"On the client side, Angular components use basic array operations and subscription-based data loading for displaying trips."

**ACTION: Open `app_admin/src/app/services/authentication.service.ts`**

**SAY:**
"Authentication tokens are stored in browser localStorage and validated client-side using manual base64 decoding and expiration checking."

### Part 2: Code Analysis (3-4 minutes)

**SCREEN: Keep `authentication.service.ts` open, scroll to lines 64-92**

**SAY:**
"Analyzing the current algorithms, I've identified several performance issues."

**SAY:**
"First, the isLoggedIn method performs JSON parsing and base64 decoding on every call without caching the result. This creates unnecessary computational overhead."

**ACTION: Go back to `app_api/controllers/trips.js`, scroll to line 44**

**SAY:**
"Second, the tripsFindCode function uses findOne with a code parameter, which while indexed, doesn't support partial matching or fuzzy search capabilities that users would expect."

**ACTION: Open `app_api/models/travlr.js`, highlight perPerson field**

**SAY:**
"Third, I notice the perPerson field is stored as a String rather than a Number. This prevents efficient price-range queries and mathematical operations."

**ACTION: Open `app_server/controllers/travel.js`**

**SAY:**
"Fourth, the travel controller uses fetch to call the local API, creating unnecessary network overhead for internal communication when we could access the database directly."

### Part 3: Planned Enhancements (2-3 minutes)

**SCREEN: Keep current file open**

**SAY:**
"My algorithmic improvements will include three key enhancements."

**SAY:**
"First, I'll implement an advanced search system using MongoDB text indexes and aggregation pipelines for complex queries, plus client-side debounced search with autocomplete functionality. This demonstrates Course Outcome 3 - using algorithmic principles for efficient solutions."

**SAY:**
"Second, I'll implement a comprehensive caching strategy using Redis for trip data and optimized token validation with memoization, significantly reducing database load and improving response times."

**SAY:**
"Third, I'll optimize data structures by restructuring the trip schema with proper data types and implementing compound indexes for multi-field queries. This showcases Course Outcome 4 - innovative techniques for industry-specific solutions."

---

## 🗄️ CATEGORY THREE: DATABASES (8-9 minutes)

### Part 1: Existing Functionality Description (2-3 minutes)

**SCREEN: Open `app_api/models/db.js`**

**SAY:**
"For the database category, let me describe the current functionality. The application uses MongoDB with Mongoose ODM for data persistence."

**SAY:**
"The database connection is established here using environment variables for host, port, and database name, with graceful shutdown handling for different termination scenarios."

**ACTION: Open `app_api/models/travlr.js`**

**SAY:**
"Our trip schema defines the structure with basic field validation and required constraints."

**ACTION: Open `app_api/models/user.js`**

**SAY:**
"The user schema handles authentication data with PBKDF2 password hashing and JWT token generation methods."

**SAY:**
""CRUD operations are implemented through Mongoose methods with async/await patterns and basic error handling in the controllers."

### Part 2: Code Analysis (3-4 minutes)

**SCREEN: Keep `app_api/models/travlr.js` open, highlight perPerson field**

**SAY:**
"Analyzing the database design, I've identified several critical issues."

**SAY:**
"First, the trip schema has inconsistent data types. The perPerson field is stored as String when it should be Number for mathematical operations and price range queries."

**ACTION: Scroll to `app_api/models/db.js`, highlight line 30**

**SAY:**
"Second, there's a coding error here - the gracefulShutdown function is declared without const or let, creating an implicit global variable which is poor practice."

**ACTION: Open `app_api/models/user.js`, scroll to line 15**

**SAY:**
"Third, examining our security implementation, the PBKDF2 hashing uses only 1000 iterations, which is significantly below current security recommendations of 10,000 or more iterations."

**SAY:**
"Fourth, database credentials rely solely on environment variables without additional encryption or secret management, and there's no input sanitization before database operations."

**SAY:**
"Finally, we're using default Mongoose connection settings without connection pooling, which isn't optimal for production load, and we have no compound indexes for complex queries."

### Part 3: Planned Enhancements (2-3 minutes)

**SCREEN: Keep current file open**

**SAY:**
"My database enhancements will implement three major improvements."

**SAY:**
"First, I'll focus on schema optimization by restructuring data types for proper querying, implementing compound indexes for common query patterns, and adding comprehensive data validation middleware. This demonstrates Course Outcome 3 - evaluating computing solutions with proper trade-off analysis."

**SAY:**
"Second, I'll implement security hardening including input sanitization middleware, increasing PBKDF2 iterations to current standards, and adding audit logging for sensitive operations. This aligns with Course Outcome 5 - security mindset development."

**SAY:**
"Third, I'll optimize performance through database connection pooling, query optimization using aggregation pipelines, and implementing database monitoring and backup strategies. This supports Course Outcome 4 - using innovative tools and techniques."

---

## 🎯 CONCLUSION (2 minutes)

**SCREEN: Show project structure overview**

**SAY:**
"In conclusion, this code review has identified specific, actionable areas for improvement across all three categories. The planned enhancements will transform this educational project into an enterprise-ready application demonstrating advanced software engineering practices, algorithmic optimization, and robust database management."

**SAY:**
"These improvements align with all five course outcomes: demonstrating professional communication through this review, using well-founded analytical principles in identifying issues, designing appropriate computing solutions through the planned architecture improvements, using innovative techniques in the optimization strategies, and developing a security mindset through the comprehensive security enhancements."

**SAY:**
"The systematic approach to these enhancements will demonstrate not only technical competency but also the ability to critically analyze existing systems and implement scalable, secure solutions that meet industry standards."

**SAY:**
"Thank you for watching this code review. The next steps will be implementing these enhancements to showcase the full range of skills developed throughout the CS 499 capstone experience."

---

## 📋 RECORDING CHECKLIST

### Before Recording:
- [ ] Open VS Code with cs-465 project loaded
- [ ] Have all files ready to navigate to quickly
- [ ] Test screen recording software
- [ ] Check audio levels
- [ ] Close unnecessary applications

### Files to Have Ready:
1. `app.js` (lines 10-11)
2. `app_api/routes/index.js` (lines 7-12)
3. `app_api/controllers/trips.js` (line 63)
4. `app_admin/src/app/utils/jwt.interceptor.ts`
5. `app_admin/src/app/services/trip-data.ts`
6. `app_admin/src/app/services/authentication.service.ts` (lines 64-92)
7. `app_api/models/travlr.js` (perPerson field)
8. `app_server/controllers/travel.js`
9. `app_api/models/db.js` (line 30)
10. `app_api/models/user.js` (line 15)

### Timing Targets:
- Introduction: 2 minutes
- Category 1: 8-9 minutes
- Category 2: 8-9 minutes
- Category 3: 8-9 minutes
- Conclusion: 2 minutes
- **Total: ~30 minutes**

### Key Success Factors:
- Reference specific line numbers
- Show actual code on screen
- Connect issues to course outcomes
- Maintain professional tone
- Speak clearly and at moderate pace
- Demonstrate deep code understanding"
